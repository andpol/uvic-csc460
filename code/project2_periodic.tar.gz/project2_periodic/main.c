/*
 * main.c
 *
 *  Created on: Jun 23, 2013
 *      Author: andpol
 *
 */

#include "os.h"
#include "PIR.h"
#include "Sonar.h"
#include "Roomba.h"
#include "BlockingUART.h"

#include <avr/io.h>
#include <stdbool.h>

#define NUM_TICKS_INTRUDER_TIMEOUT 1000
#define TURN_VELOCITY 100
#define DRIVE_VELOCITY 200
#define SONAR_EPSILON 5
#define FOLLOW_DISTANCE 100

enum TASKS {
	PIR_CHECK = 1, SONAR_PING, FSM_TRANSITION, ADJUST_MOVEMENT, ROOMBA_SENSOR_QUERY,
};

typedef enum {
	PATROLLING, INTRUDER_DETECTED,
} FSM;

FSM fsm = PATROLLING;

// Latest sensor readings
bool are_you_there = false;
int distance = 100;
ROOMBA_PACKET_1 roomba_sensor_data;

const unsigned int PT = 5;
const unsigned char PPP[] = { PIR_CHECK, 1, SONAR_PING, 10, ROOMBA_SENSOR_QUERY, 4, FSM_TRANSITION, 1, ADJUST_MOVEMENT, 3 };

void pir_check() {
	for (;;) {
		are_you_there = get_PIR_state();
		Task_Next();
	}
}

void sonar_ping() {
	for (;;) {
		distance = (distance + get_sonar_distance()) / 2;
		Task_Next();
	}
}
void fsm_transition() {
	static unsigned int intruder_detect_timestamp;
	for (;;) {
		if (are_you_there) {
			// If the PIR is triggered, go into the INTRUDER_DETECTED state
			fsm = INTRUDER_DETECTED;
			intruder_detect_timestamp = Now();
		} else if (fsm == INTRUDER_DETECTED) {
			unsigned int delta = Now() - intruder_detect_timestamp;
			if (delta >= NUM_TICKS_INTRUDER_TIMEOUT || roomba_sensor_data.virtual_wall) {
				fsm = PATROLLING;
			}
		}
		Task_Next();
	}
}
void adjust_movement() {
	bool in_virtual_wall = false;
	for (;;) {
		if (fsm == PATROLLING) {
			if (roomba_sensor_data.bumps_wheeldrops & 2) {
				// Turn Right
				roomba_drive(TURN_VELOCITY, -1);
			} else if (roomba_sensor_data.bumps_wheeldrops & 1) {
				// Turn Left
				roomba_drive(TURN_VELOCITY, 1);
			} else if (roomba_sensor_data.virtual_wall) {
				if (!in_virtual_wall) {
					// Turn Left
					roomba_drive(TURN_VELOCITY, 1);
					in_virtual_wall = true;
				}
			} else {
				// No relevant sensors triggered, drive straight
				roomba_drive(DRIVE_VELOCITY, RADIUS_STRAIGHT);
				in_virtual_wall = false;
			}
		} else if (fsm == INTRUDER_DETECTED) {
			// Too close
			if (distance < FOLLOW_DISTANCE - SONAR_EPSILON) {
				roomba_drive(-DRIVE_VELOCITY, RADIUS_STRAIGHT);
			}
			// Too far
			else if (distance > FOLLOW_DISTANCE + SONAR_EPSILON) {
				roomba_drive(DRIVE_VELOCITY, RADIUS_STRAIGHT);
			}
			// Stay still
			else {
				roomba_drive(0, RADIUS_STRAIGHT);
			}
		}
		Task_Next();
	}
}
void roomba_sensor_query() {
	for (;;) {
		roomba_sensor_data = roomba_sense_1();
		Task_Next();
	}
}

int r_main() {
	// LED
	DDRB |= _BV(PB0);

	UART_Init0(57600);
	init_PIR();
	init_sonar();
	init_roomba();

	_delay_ms(200);

	Task_Create(pir_check, 0, PERIODIC, PIR_CHECK);
	Task_Create(sonar_ping, 0, PERIODIC, SONAR_PING);
	Task_Create(fsm_transition, 0, PERIODIC, FSM_TRANSITION);
	Task_Create(adjust_movement, 0, PERIODIC, ADJUST_MOVEMENT);
	Task_Create(roomba_sensor_query, 0, PERIODIC, ROOMBA_SENSOR_QUERY);

	return 0;
}
