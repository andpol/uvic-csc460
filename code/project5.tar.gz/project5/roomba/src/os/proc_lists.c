#include "proc_lists.h"

void proc_list_init(proc_list_t * list) {
	list->head = list->tail = NULL;
	list->len = 0;
}

void proc_list_append(proc_list_t * list, process_descriptor_t * proc) {
	if (list->len == 0) {
		list->head = list->tail = proc;
	} else {
		list->tail->next = proc;
	}
	list->tail = proc;
	proc->next = NULL;
	list->len++;
}

process_descriptor_t * proc_list_pop(proc_list_t * list) {
	if (list->len == 0) {
		return NULL;
	} else if (list->len == 1) {
		process_descriptor_t * p = list->head;
		list->head = list->tail = NULL;
		list->len = 0;
		return p;
	} else {
		process_descriptor_t * p = list->head;
		list->head = p->next;
		list->len--;
		return p;
	}
}

process_descriptor_t * proc_list_peek(proc_list_t * list) {
	return list->head;
}

void proc_list_insert_into_offset_order(proc_list_t * list, process_descriptor_t * proc) {
	if (list->len == 0) {
		list->head = list->tail = proc;
	} else {
		process_descriptor_t * p = list->head;
		process_descriptor_t * p_prev = NULL;
		while (p != NULL && p->next_start < proc->next_start) {
			p_prev = p;
			p = p->next;
		}

		if (p_prev == NULL) {
			// Insert as first element in list
			list->head = proc;
			proc->next = p;
		} else if (p == NULL) {
			// Insert as last element in list
			list->tail = proc;
			p_prev->next = proc;
			proc->next = NULL;
		} else {
			// Somewhere in the middle, insert between p_prev and p
			p_prev->next = proc;
			proc->next = p;
		}
	}
	list->len++;
}

process_descriptor_t * proc_list_pop_first(proc_list_t * list, process_state_t state) {
	process_descriptor_t * p;
	if (list->len == 0) {
		p = NULL;
	} else if (list->len == 1) {
		p = list->head;
		list->len = 0;
		list->head = list->tail = NULL;
	} else {
		process_descriptor_t * p_prev = NULL;
		p = list->head;
		while (p != NULL && p->state != state) {
			p_prev = p;
			p = p->next;
		}
		if (p_prev == NULL) {
			// First element in list
			list->head = p->next;
		} else if (p == NULL) {
			// Last element in list
			list->tail = p_prev;
		} else {
			// Somewhere in the middle
			p_prev->next = p->next;
		}
		p->next = NULL;
	}

	return p;
}
