/*
 * linked_list.h
 *
 *  Created on: Jul 7, 2013
 *      Author: andpol
 */

#ifndef LINKED_LIST_H_
#define LINKED_LIST_H_

#include <stdlib.h>
#include <avr/common.h>

#include "error.h"
#include "os.h"

typedef enum {
	RUNNING, // Process is currently running
	BLOCKED, // Process is blocked by an event
	READY,   // Process is ready to run
	DEAD,	 // Process has not yet been allocated and does not have a SP
} process_state_t;

typedef struct d_struct process_descriptor_t;
struct d_struct {
	// The stack for the process
	uint8_t stack[MAXSTACK];
	// Pointer to the HW stack pointer
	volatile uint8_t sp[3];
	// Process ID
	uint8_t pid;
	// Type (IDLE, SYSTEM, PERIODIC, or RR)
	uint8_t type;
	// Argument passed by the init function
	int arg;
	// The current state of the process
	process_state_t state;
	// The remaining number of ticks for the process
	uint32_t ticks_remaining;
	// The tick number for when the next
	uint32_t next_start;
	// The period of the process (in ticks) (only used for PERIODIC procs)
	uint32_t period;
	// The worst case execution time of the process (in ticks) (only used for PERIODIC procs)
	uint32_t wcet;
	// A pointer to the next item in the linked list (or NULL if none)
	process_descriptor_t * next;
};

typedef struct {
	uint8_t len;
	process_descriptor_t * head;
	process_descriptor_t * tail;
} proc_list_t;

proc_list_t system_procs;
proc_list_t periodic_procs;
proc_list_t rr_procs;
proc_list_t waiting_procs;
process_descriptor_t * idle_proc;

void proc_list_init(proc_list_t * list);
void proc_list_append(proc_list_t * list, process_descriptor_t * proc);
process_descriptor_t * proc_list_pop(proc_list_t * list);
process_descriptor_t * proc_list_peek(proc_list_t * list);
void proc_list_insert_into_offset_order(proc_list_t * list, process_descriptor_t * proc);
process_descriptor_t * proc_list_pop_first(proc_list_t * list, process_state_t state);

#endif /* LINKED_LIST_H_ */
