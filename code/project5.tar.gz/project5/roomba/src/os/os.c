/*
 * os.c
 *
 *  Created on: Jul 7, 2013
 *      Author: andpol
 */

#include "os.h"
#include "kernel.h"
#include "error.h"
#include "proc_lists.h"

#include "../uart/BlockingUART.h"

#include <avr/interrupt.h>
#include <avr/io.h>
#include <util/delay.h>

#include <stdbool.h>
#include <stdlib.h>

//#define DEBUG 1

// Ignore all "main" warnings, since we are supplying our own crt0.S
#pragma GCC diagnostic ignored "-Wmain"

// NOTE: Output compare register set for a prescaler of 8!
#define OCR_MAX_VAL (TICK * (F_CPU / 8L ) / 1000)

typedef struct event {
	// The process ID of the waiting process, '-1' if none.
	int8_t waiting_pid;
	bool signaled;
} EVENT;

/*
 * The "naked" attribute prevents the compiler from adding instructions
 * to save and restore register values. It also prevents an
 * automatic return instruction.
 */
void TIMER1_COMPA_vect(void) __attribute__ ((signal, naked));

/* ============= GLOBALS ============= */

// To be defined and implemented by the RTOS application, called after OS_Init()
extern void main(void);

// The array of available events, and the count of the initialized events
uint8_t event_count = 0;
EVENT events[MAXEVENT];

/* ============= OS API ============= */
static void idle() {
	for (;;) {
	}
}

void init_tick_timer() {
	OCR1A = OCR_MAX_VAL;
	// Enable output compare interrupts
	TIMSK1 = _BV(OCIE1A);
	// Start the timer with a prescaler of 8
	TCCR1B = _BV(CS11);
}

void init_proc_descriptors() {
	proc_list_init(&system_procs);
	proc_list_init(&rr_procs);
	int i;
	for (i = 0; i < MAXPROCESS + 1; i++) {
		procs[i].state = DEAD;
	}
}

ISR(TIMER1_COMPA_vect) {
	SAVE_CTX_TOP();
	STACK_SREG_SET_I_BIT();
	SAVE_CTX_BOTTOM();
//	cur_process->sp = (uint8_t *) ((((uint16_t) *(&SP + 1) << 8) | (uint16_t) SP ));
	cur_process->sp[0] = EIND;
	cur_process->sp[1] = *(&SP + 1);
	cur_process->sp[2] = SP;

	// Set the OCR for triggering the interrupt for the next tick (AFTER we've saved the context)
	num_ticks++;
	OCR1A += OCR_MAX_VAL;
	kernel_request = K_REQ_TIMER_TICK;

	// Restore the kernel's context, SP first.
	// XXX: set the SP bytes manually, since setting the SP directly doesn't work!
//	SP = (uint8_t) (kernel_sp);
//	*(&SP + 1) = (uint8_t) ((volatile uint16_t) kernel_sp >> 8);
	EIND = kernel_sp[0];
	*(&SP + 1) = kernel_sp[1];
	SP = kernel_sp[2];

	// Now restore I/O and SREG registers.
	RESTORE_CTX();

	/*
	 * Assembly return instruction required since the C-level return expands to assembly code that
	 * restores context, but we do that manually. Returns to kernel context.
	 */
	asm volatile ("ret\n"::);
}

void OS_Init(void) {
	sei();
#ifdef DEBUG
	UART_Init(UART_CH_0, 57600);
	UART_print(UART_CH_0, "\nboot\n");
#endif
	// Init variables
	os_err_handler = NULL;
	errno = ERRNO_NO_ERROR;

	// Init kernel timer and data structures
	init_proc_descriptors();

	// Create the background IDLE task
	idle_proc = cur_process = kernel_create_proc(IDLE, idle);
	idle_proc->state = RUNNING;

	// Call the application's main()
	main();

	init_tick_timer();
	kernel_main_loop();
}

void OS_Abort() {
	// Clear interrupts, this is an irrecoverable error, we don't want to leave this function ever.
	cli();

	if (os_err_handler != NULL ) {
		os_err_handler();
	}

#ifdef DEBUG
	UART_print(UART_CH_0, "ABORT! ERRNO: %d", errno);
#endif

	DDRB |= _BV(PB7);
	int i;
	for (;;) {
		for (i = 0; i < errno; i++) {
			// Flash PB7 LED 'errno' number of times
			PORTB |= _BV(PB7);
			_delay_ms(300);
			PORTB = 0;
			_delay_ms(300);
		}
		PORTB |= _BV(PB7);
		_delay_ms(1000);
	}
}

int Task_Create_System(void (*f)(void), int arg) {
	process_descriptor_t * p = kernel_create_proc(SYSTEM, f);
	p->arg = arg;
	proc_list_append(&system_procs, p);
	return p->pid;
}

int Task_Create_RR(void (*f)(void), int arg) {
	process_descriptor_t * p = kernel_create_proc(RR, f);
	p->arg = arg;
	p->ticks_remaining = RR_TICK;
	proc_list_append(&rr_procs, p);
	return p->pid;
}

int Task_Create_Period(void (*f)(void), int arg, unsigned int period, unsigned int wcet, unsigned int start) {
	process_descriptor_t * p = kernel_create_proc(PERIODIC, f);
	p->arg = arg;

	p->period = period;
	p->wcet = wcet;
	p->next_start = num_ticks + start;
	p->ticks_remaining = wcet;

	proc_list_insert_into_offset_order(&periodic_procs, p);

	return p->pid;
}

void Task_Terminate(void) {
	uint8_t sreg = SREG;
	cli();

	kernel_request = K_REQ_TASK_TERMINATE;
	enter_kernel();

	SREG = sreg;
}

void Task_Next(void) {
	uint8_t sreg = SREG;
	cli();

	kernel_request = K_REQ_TASK_NEXT;
	enter_kernel();

	SREG = sreg;
}

int Task_GetArg(void) {
	return cur_process->arg;
}

/* =====  Events API ===== */

EVENT * Event_Init(void) {
	if (event_count >= MAXEVENT) {
		errno = ERRNO_EXCEEDS_MAX_EVENT;
		OS_Abort();
	}
	EVENT * e = &events[event_count++];
	e->waiting_pid = -1;
	e->signaled = false;
	return e;
}

void Event_Clear(EVENT *e) {
	uint8_t sreg = SREG;
	cli();

	e->waiting_pid = -1;
	e->signaled = false;

	SREG = sreg;
}

void Event_Wait(EVENT *e) {
	uint8_t sreg = SREG;
	cli();

	if (e->signaled) {
		e->signaled = false;
		e->waiting_pid = -1;
	} else {
		if (e->waiting_pid != -1) {
			errno = ERRNO_MULTIPLE_TASKS_CALLED_WAIT;
			OS_Abort();
		}
		e->waiting_pid = cur_process->pid;
		kernel_request = K_REQ_TASK_WAIT;
		enter_kernel();
		SREG = sreg;
	}

	SREG = sreg;
}

void Event_Wait_Next(EVENT *e) {
	uint8_t sreg = SREG;
	cli();

	Event_Clear(e);
	Event_Wait(e);

	SREG = sreg;
}

void Event_Signal(EVENT *e) {
	uint8_t sreg = SREG;
	cli();

	if (e->signaled) {
		// NOP - event already signaled
	} else if (e->waiting_pid == -1) {
		// No waiting process
		e->signaled = true;
	} else {
		// Waiting process, wake it up.
		procs[e->waiting_pid].state = READY;
		kernel_request = K_REQ_TASK_SIGNAL;
		// Clear the waiting process's PID (since we're going to wake it up immediately)
		e->waiting_pid = -1;
		enter_kernel();
	}

	SREG = sreg;
}

void Event_Async_Signal(EVENT *e) {
	// OPTIONAL: BONUS
	// TODO
}

/* =====  System Clock API ===== */

// number of milliseconds since the RTOS boots.
unsigned int Now() {
	return num_ticks * TICK + TCNT0 / OCR_MAX_VAL;
}
