#include "Roomba.h"

#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <stdarg.h> // For varargs
#include "../uart/BlockingUART.h"
#include <string.h>

#include <stdlib.h>

#define ROOMBA_UART_CHANNEL UART_CH_2

/**
 *  Send a command to the Roomba
 * @param opcode
 * 			the opcode of the command
 * @param num_data_bytes
 * 			the number of vararg data bytes to follow
 * @param ...
 * 			the variable argument data bytes to send
 */
void _roomba_send_command(_ROOMBA_OPCODE opcode, uint8_t num_data_bytes, uint8_t * data) {
	uint8_t packet[num_data_bytes + 1];
	packet[0] = (uint8_t) opcode;
	memcpy(&packet[1], data, num_data_bytes);

	UART_send_raw_bytes(ROOMBA_UART_CHANNEL, num_data_bytes + 1, packet);
}

void RoombaInit() {
	// Wake up the Roomba by sending a low signal on the roomba[DD] pin for 500ms
	DDRJ |= _BV(PJ0);
	PORTJ &= ~_BV(PJ0);
	_delay_ms(500);

	UART_Init(ROOMBA_UART_CHANNEL, 57600);

	// Put Roomba into PASSIVE MODE
	_roomba_send_command(OC_START, 0, NULL );
	_delay_ms(20);
	// Put Roomba into SAFE mode
	_roomba_send_command(OC_CONTROL, 0, NULL );
	_delay_ms(20);
}

void RoombaDrive(int16_t velocity, int16_t radius) {
	uint8_t data[4];
	data[0] = (uint8_t) (velocity >> 8);
	data[1] = (uint8_t) (velocity & 0xFF);
	data[2] = (uint8_t) (radius >> 8);
	data[3] = (uint8_t) (radius & 0xFF);

	_roomba_send_command(OC_DRIVE, 4, data);
}

// Not guaranteed to be accurate. Negative is left, Positive is right
void RoombaTurn(int16_t angle) {
	RoombaDrive(100, angle > 0 ? -1 : 1);
	uint16_t top = ((uint16_t) abs(angle)) * 23;
	uint16_t i;
	for (i = 0; i < top; i++) {
		_delay_ms(1);
	}
	RoombaDrive(0, ROOMBA_RADIUS_STRAIGHT);
}

// Blocking call
ROOMBA_PACKET_1 RoombaSense1() {

	// Send request
	uint8_t data[] = { (uint8_t) ROOMBA_SENSOR_PACKET_1 };
	_roomba_send_command(OC_SENSORS, 1, data);

	// Recieve into a buffer
	int packet_size = sizeof(ROOMBA_PACKET_1);
	uint8_t buffer[packet_size];

	// Busy wait until entire packet is read
	int i = 0;
	while (i < packet_size) {
		buffer[i++] = UART_Receive(ROOMBA_UART_CHANNEL);
	}

	ROOMBA_PACKET_1 packet;
	memcpy(&packet, buffer, packet_size);

	return packet;
}

// Blocking call
ROOMBA_PACKET_2 RoombaSense2() {

	// Send request
	uint8_t data[] = { (uint8_t) ROOMBA_SENSOR_PACKET_2 };
	_roomba_send_command(OC_SENSORS, 1, data);

	// Recieve into a buffer
	int packet_size = sizeof(ROOMBA_PACKET_2);
	uint8_t buffer[packet_size];

	// Busy wait until entire packet is read
	int i = 0;
	while (i < packet_size) {
		buffer[i++] = UART_Receive(ROOMBA_UART_CHANNEL);
	}

	ROOMBA_PACKET_2 packet;
	memcpy(&packet, buffer, packet_size);

	// Flip distance/angle bytes, since AVR is little-endian
	packet.distance = ((buffer[2]) << 8) | (buffer[3]);
	packet.angle = ((buffer[4]) << 8) | (buffer[5]);

	return packet;
}
