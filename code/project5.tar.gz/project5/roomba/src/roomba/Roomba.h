/*
 * Roomba.h
 *
 *  Created on: May 21, 2013
 *      Author: andpol
 *
 *
 *      Wiring:
 *      roomba[DD] -> PJ0 (RX3 - Arduino #15)
 *      roomba[TX] -> RX2
 *      roomba[RX] -> TX2
 */

#ifndef ROOMBA_H_
#define ROOMBA_H_

#include <stdint.h>
#include <stdbool.h>

#define ROOMBA_RADIUS_STRAIGHT 0x8000

typedef enum {
	OC_START = 128,
	OC_BAUD,
	OC_CONTROL,
	OC_SAFE,
	OC_FULL,
	OC_POWER,
	OC_SPOT,
	OC_CLEAN,
	OC_MAX,
	OC_DRIVE,
	OC_MOTORS,
	OC_LEDS,
	OC_SONG,
	OC_PLAY,
	OC_SENSORS,
	OC_FORCE_SEEKING_DOCK,
} _ROOMBA_OPCODE;

typedef enum {
	ROOMBA_SENSOR_PACKET_ALL = 0, ROOMBA_SENSOR_PACKET_1, ROOMBA_SENSOR_PACKET_2, ROOMBA_SENSOR_PACKET_3,
} ROOMBA_SENSOR_PACKET;

typedef struct {
	uint8_t bumps_wheeldrops;
	uint8_t wall;
	uint8_t cliff_left;
	uint8_t cliff_front_left;
	uint8_t cliff_front_right;
	uint8_t cliff_right;
	uint8_t virtual_wall;
	uint8_t motor_overcurrents;
	uint8_t dirt_detector_left;
	uint8_t dirt_detector_right;
} ROOMBA_PACKET_1;

typedef struct {
	uint8_t remote_opcode;
	uint8_t buttons;
	int16_t distance;
	int16_t angle;
} ROOMBA_PACKET_2;

typedef struct {
	uint8_t charging_state;
	uint16_t voltage;
	uint16_t current;
	uint8_t temperature;
	uint16_t charge;
	uint16_t capacity;
} ROOMBA_PACKET_3;

/* ****** API BEGIN ******** */

void RoombaInit();
void RoombaDrive(int16_t velocity, int16_t radius);
// Not guaranteed to be accurate. Negative is left, Positive is right
void RoombaTurn(int16_t angle);
// Blocking call
ROOMBA_PACKET_1 RoombaSense1();
// Blocking call
ROOMBA_PACKET_2 RoombaSense2();

#endif /* ROOMBA_H_ */
