/*
 * servo.c
 *
 *  Created on: Aug 16, 2013
 *      Author: andpol
 */

#include "servo.h"

#include "util/delay.h"
#include "avr/io.h"

// Speed of the servo, measured in micro-seconds/degree
#define SERVO_SPEED_US_D 3833 // 0.23 seconds / 60 degrees
// Value PWM timer counts up to. 40000 => 20 ms period with 8 prescaler
#define PWM_TOP_PERIOD 40000

#define PULSE_WIDTH_CENTER 1350
// Sonar PWM signal offset from center (left and right) to make the sonar range +/- 90 degrees
#define PULSE_WIDTH_DELTA 870
// Sonar PWM signal pulse width constraints
#define PULSE_WIDTH_MIN (PULSE_WIDTH_CENTER - PULSE_WIDTH_DELTA)
#define PULSE_WIDTH_MAX (PULSE_WIDTH_CENTER + PULSE_WIDTH_DELTA)

#define ABS(x) (x > 0 ? x : -x)

int current_servo_angle = 0;

void set_pulse_width(uint16_t microseconds) {
	// Sanity check so we don't break the sonar
	if (microseconds > PULSE_WIDTH_MAX || microseconds < PULSE_WIDTH_MIN) {
		return;
	}
	// USING 8 prescaler!
	OCR3C = F_CPU / 8 / 1000 * microseconds / 1000;
}

void ServoSetAngle(int angle) {
	// Check for errors, cap the possible angle
	if (angle > 90) {
		angle = 90;
	} else if (angle < -90) {
		angle = -90;
	}

	if (angle == 0) {
		set_pulse_width(PULSE_WIDTH_CENTER);
	} else {
		int delta_pwm = ((int32_t) angle) * PULSE_WIDTH_DELTA / 90;
		set_pulse_width(PULSE_WIDTH_CENTER - delta_pwm);
	}

	// Block while the servo is turning
	uint8_t abs_delta_angle = ABS(angle > current_servo_angle ? angle - current_servo_angle : current_servo_angle - angle);
	for (; abs_delta_angle > 0; abs_delta_angle--) {
		_delay_us(SERVO_SPEED_US_D * 2);
	}

	current_servo_angle = angle;
}

int ServoGetAngle() {
	return current_servo_angle;
}

void ServoInit() {
	// PE5 = OC3C = Pin #3
	DDRE = _BV(PE5);

	// Clear OC3C on compare match, set at BOTTOM
	TCCR3A = _BV(COM3C1);

	// Fast PWM mode, TOP = OCR3A
	TCCR3A |= _BV(WGM31) | _BV(WGM30);
	TCCR3B |= _BV(WGM33) | _BV(WGM32);

	// Set the PWM period using the TOP compare register
	OCR3A = PWM_TOP_PERIOD;

	// Set the servo to the center
	set_pulse_width(PULSE_WIDTH_CENTER);

	// Start timer with 8 prescaler
	TCCR3B |= _BV(CS31);
}
