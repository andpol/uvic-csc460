/*
 * servo.h
 *
 *  Created on: Aug 16, 2013
 *      Author: andpol
 *
 *
 *      Uses timer #3 and outputs PWM signal on PE5
 */

#ifndef SERVO_H_
#define SERVO_H_

#include <stdint.h>

/*
 * Initialize and turn on the servo. Servo resets itself to the 0 degree position.
 */
void ServoInit();

/*
 * Set the angle of the servo. Blocking call until in servo is in position.
 *
 * @param angle
 * 			the angle in degrees, in the range [-90, 90]
 */
void ServoSetAngle(int angle);

int ServoGetAngle();


#endif /* SERVO_H_ */
