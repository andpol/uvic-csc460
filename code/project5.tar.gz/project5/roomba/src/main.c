#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdbool.h>

//#define DEBUG

#define ROOMBA_NUMBER 0

// Ignore all "main" warnings, since we are supplying our own crt0.S
#pragma GCC diagnostic ignored "-Wmain"

#include "os/os.h"
#include "radio/packet.h"
#include "radio/radio.h"
#include "uart/BlockingUART.h"
#include "roomba/Roomba.h"

#include "servo/servo.h"
#include "sonar/Sonar.h"

EVENT * readPacketEvent;
EVENT * sonarSweepEvent;
EVENT * headingPacketReceivedEvent;

uint8_t base_station_addr[5] = { 0x01, 0x01, 0x01, 0x01, 0x01 };
uint8_t roomba_addresses[2][5] = { { 0x02, 0x02, 0x02, 0x02, 0x02 }, { 0x03, 0x03, 0x03, 0x03, 0x03 } };
uint8_t * roomba_addr = roomba_addresses[ROOMBA_NUMBER];

radiopacket_t tx_packet;
radiopacket_t rx_packet;

// Only to be accessed after a headingPacketReceivedEvent has been signaled
pf_heading_reply_t heading_packet_reply;

// 5 degrees of separation between each sample from -90 to 90 => 37
#define NUM_SONAR_POINTS 37
#define SONAR_DEGREE_DELTA 5

// Most recent sonar sweep data in cm
int16_t sonar_sweep_data[NUM_SONAR_POINTS];

// Minimum distance required for the roomba to travel in a specific direction, in cm
#define MIN_ROOMBA_TRAVEL_DISTANCE_CM 50

// Anything above this value will be ignored as a valid sonar point
#define MAX_SONAR_DISTANCE_VALUE 200

void radio_rxhandler(uint8_t pipenumber) {
	Event_Signal(readPacketEvent);
}

// Returns true if successful, false otherwise
inline bool transmit_packet() {
#ifdef DEBUG
	UART_print(UART_CH_0, "Tx...\n");
#endif
//	Radio_Set_Tx_Addr(base_station_addr);
	PORTB |= _BV(PB7);
	if (Radio_Transmit(&tx_packet, RADIO_WAIT_FOR_TX) == RADIO_TX_MAX_RT) {
//	 TODO: FIXME!!! BELOW LINE DOESN"T RETURN AFTER RECEIVING A REPLY!
//	if (Radio_Transmit(&tx_packet, RADIO_RETURN_ON_TX) == RADIO_TX_MAX_RT) {
#ifdef DEBUG
		UART_print(UART_CH_0, "Tx Fail\n");
#endif
		PORTB &= ~_BV(PB7);
		return false;
	} else {
#ifdef DEBUG
		UART_print(UART_CH_0, "Tx Success\n");
#endif
		PORTB &= ~_BV(PB7);
		return true;
	}
}

static inline void transmit_sonar_packet(int16_t distance, int16_t theta) {
	tx_packet.type = PACKET_SONAR;
	tx_packet.payload.sonar.roomba_id = ROOMBA_NUMBER;
	tx_packet.payload.sonar.distance = distance;
	tx_packet.payload.sonar.theta = theta;

#ifdef DEBUG
	UART_print(UART_CH_0, "Sonar ");
#endif
	transmit_packet();
}

// Blocking transmission, only returns upon successful transmit
static inline void transmit_position_packet_blocking(int16_t delta_x, int16_t delta_y, int16_t alpha) {
	tx_packet.type = PACKET_POSITION;
	tx_packet.payload.position.roomba_id = ROOMBA_NUMBER;
	tx_packet.payload.position.delta_x = delta_x;
	tx_packet.payload.position.delta_y = delta_y;
	tx_packet.payload.position.alpha = alpha;

#ifdef DEBUG
	UART_print(UART_CH_0, "Position ");
#endif
	// Keep trying!
	while (!transmit_packet()) {
		_delay_ms(25);
	}
}

// Blocking transmission, only returns upon successful transmit
static inline void transmit_heading_request_packet_blocking() {
	tx_packet.type = PACKET_HEADING_REQUEST;
	tx_packet.payload.heading_req.roomba_id = ROOMBA_NUMBER;

#ifdef DEBUG
	UART_print(UART_CH_0, "Heading req ");
#endif
	// Keep trying!
	while (!transmit_packet()) {
		_delay_ms(25);
	}
}

// Blocking transmission, only returns upon successful transmit
static inline void transmit_bump_packet_blocking() {
	tx_packet.type = PACKET_BUMP;
	tx_packet.payload.bump.roomba_id = ROOMBA_NUMBER;

#ifdef DEBUG
	UART_print(UART_CH_0, "Bump ");
#endif
	// Keep trying!
	while (!transmit_packet()) {
		_delay_ms(25);
	}
}

// Returns the number of mm traveled since last polled
static inline int16_t calculate_and_transmit_roomba_coords() {
	ROOMBA_PACKET_2 p2 = RoombaSense2();
#ifdef DEBUG
	UART_print(UART_CH_0, "d: %d, a: %d\n", p2.distance, p2.angle);
#endif
	double angle_rad = -2.0 * ((double) p2.angle) / 258.0;
	double dX = sin(angle_rad) * ((double) p2.distance);
	double dY = cos(angle_rad) * ((double) p2.distance);
	double angle_deg = angle_rad * 180.0 / 3.141592;
#ifdef DEBUG
	UART_print(UART_CH_0, "dX: %d, dY: %d, angle: %d\n", (int16_t) dX, (int16_t) dY, (int16_t) angle_deg);
#endif

	transmit_position_packet_blocking(dX, dY, angle_deg);
	return p2.distance;
}

void task_read_packet() {
	for (;;) {
		// The readPacketEvent is signaled is set by radio_rxhandler when packet ready to be received
		Event_Wait(readPacketEvent);

		if (Radio_Receive(&rx_packet) == RADIO_RX_MORE_PACKETS) {
			// More packets to be read, signal our own event
			Event_Signal(readPacketEvent);
		};

		switch (rx_packet.type) {
			case PACKET_HEADING_REPLY:
#ifdef DEBUG
				UART_print(UART_CH_0, "Rx heading reply\n");
#endif
				heading_packet_reply = rx_packet.payload.heading_reply;
				Event_Signal(headingPacketReceivedEvent);
				break;
			default:
#ifdef DEBUG
				UART_print(UART_CH_0, "Rx unknown packet\n");
#endif
				// NOP
				break;
		}
	}
}

void task_sonar_sweep() {
	ServoSetAngle(90);
	static bool isRight = true;
	int i = 0;
	for (;;) {
		// Wait until signaled before performing a sonar sweep
		Event_Wait(sonarSweepEvent);

		for (;;) {
			// Get sonar reading, TODO: average several readings?
			int j = 0;
			uint16_t d[3] = { 0, 0, 0 };
			for (;;) {
				UART_print(UART_CH_0, "p");
				d[j] = SonarGetDistance();
				_delay_ms(50);
				if ((abs(d[0] - d[1]) == 0) && (abs(d[0] - d[2]) == 0) && (abs(d[1] - d[2]) == 0)) {
					break;
				}
				j = (j + 1) % 3;
			}
			sonar_sweep_data[i] = (d[0] + d[1] + d[2]) / 3;
			UART_print(UART_CH_0, "\nd: %d\n", sonar_sweep_data[i]);
			// Only use in-range data points (within 255 inches or ~647cm minus a buffer)
			if (sonar_sweep_data[i] > MAX_SONAR_DISTANCE_VALUE) {
				sonar_sweep_data[i] = -1;
			}
			transmit_sonar_packet(sonar_sweep_data[i] * 10, ServoGetAngle());

			// Reached full right/left
			if ((isRight && ServoGetAngle() == -90) || (!isRight && ServoGetAngle() == 90)) {
				isRight = !isRight;
				i = 0;
				break;
			}
			ServoSetAngle(ServoGetAngle() + (isRight ? -SONAR_DEGREE_DELTA : +SONAR_DEGREE_DELTA));
			i++;
		}
	}
}

void task_main_logic() {
	for (;;) {
		for (;;) {
// *** STATE: Sonar Sweep
			Event_Signal(sonarSweepEvent);
// *** STATE: Sweep Done, ensure we have a direction to travel and request heading from base station
			int i;
			for (i = 0; i < NUM_SONAR_POINTS; i++) {
				if (sonar_sweep_data[i] >= MIN_ROOMBA_TRAVEL_DISTANCE_CM) {
					goto outside_loop;
				}
			}
			UART_print(UART_CH_0, "nowhere to go!\n");
			// No places to go, turn left and try again
			RoombaTurn(-90);
			calculate_and_transmit_roomba_coords();
		}
		outside_loop: memset(sonar_sweep_data, 0, NUM_SONAR_POINTS);
		_delay_ms(50);
		transmit_heading_request_packet_blocking();
// *** STATE: Waiting for Heading
		Event_Wait(headingPacketReceivedEvent);
		// Turn to heading
		RoombaTurn(heading_packet_reply.theta);
		_delay_ms(25);
		calculate_and_transmit_roomba_coords();
// *** STATE: Driving, drive forwards for specified distance, or until hit wall, transmitting position changes with base station
		RoombaDrive(100, ROOMBA_RADIUS_STRAIGHT);
		uint16_t total_distance_mm = 0;
		uint16_t i = 0;
		for (;;) {
			ROOMBA_PACKET_1 p1 = RoombaSense1();
			if (p1.bumps_wheeldrops & 0x03) {
				// Wall hit, trasmit bump and reverse for a bit
				RoombaDrive(0, ROOMBA_RADIUS_STRAIGHT);
				transmit_bump_packet_blocking();
				_delay_ms(50);
				RoombaDrive(-100, ROOMBA_RADIUS_STRAIGHT);
				_delay_ms(750);
				calculate_and_transmit_roomba_coords();
				break;
			}
			// We don't want to sample the distance/angle too frequently
			if (i % 10 == 0) {
				total_distance_mm += calculate_and_transmit_roomba_coords();
				if (total_distance_mm >= MIN_ROOMBA_TRAVEL_DISTANCE_CM * 10) {
					// Distance traveled
					break;
				}
			}
			_delay_ms(50);
			i++;
		}
		RoombaDrive(0, ROOMBA_RADIUS_STRAIGHT);
	}
}

void main() {
#ifdef DEBUG
	UART_Init(UART_CH_0, 57600);
	UART_print(UART_CH_0, "boot\n");
#endif
	DDRB |= _BV(PB7);
	PORTB &= ~_BV(PB7);

	sonarSweepEvent = Event_Init();
	readPacketEvent = Event_Init();
	headingPacketReceivedEvent = Event_Init();

	Task_Create_RR(task_main_logic, 0);
	Task_Create_System(task_sonar_sweep, 0);
	Task_Create_System(task_read_packet, 0);

	ServoInit();
	SonarInit();

// *** Init Radio
	Radio_Init();
	Radio_Configure_Rx(RADIO_PIPE_0, roomba_addr, ENABLE);
	Radio_Configure(RADIO_1MBPS, RADIO_HIGHEST_POWER);
	Radio_Set_Tx_Addr(base_station_addr);
// ***

	RoombaInit();

	_delay_ms(500);

	// Clear the distance/angle values on the Roomba
	RoombaSense2();
	// Roomba get's initialized at the origin, pointing directly "NORTH"
	transmit_position_packet_blocking(0, 0, 0);
	_delay_ms(50);
	transmit_heading_request_packet_blocking();  // <--- DO NOT DELET ME!!! I NEED TO BE HERE FOR RADIO TO WORK!!!!???!!!
}
