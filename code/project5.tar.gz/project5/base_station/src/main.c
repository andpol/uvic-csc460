#include <util/delay.h>
#include <avr/interrupt.h>
#include <stdbool.h>

#define DEBUG

#define SONAR_NUM_DATA_POINTS 37

// Ignore all "main" warnings, since we are supplying our own crt0.S
#pragma GCC diagnostic ignored "-Wmain"

#include "os/os.h"
#include "radio/packet.h"
#include "radio/radio.h"
#include "uart/BlockingUART.h"
#include "android/android.h"

typedef enum {
	ROOMBA_1 = 0, ROOMBA_2,
} ROOMBA_NUMBER;

uint8_t base_station_addr[5] = { 0x01, 0x01, 0x01, 0x01, 0x01 };

uint8_t roomba_addr[2][5] = { { 0x02, 0x02, 0x02, 0x02, 0x02 }, // ROOMBA 1
		{ 0x03, 0x03, 0x03, 0x03, 0x03 }, // ROOMBA 2
		};

// BELOW IS TEMPORARY!
int32_t roomba_pos[] = { 0, 0 };
int data_point_index = 0;
/**
 * 0 - x position (mm)
 * 1 - y position (mm)
 * 2 - theta
 * 3 - distance from roomba location
 */
int16_t data_points[SONAR_NUM_DATA_POINTS][4];

radiopacket_t tx_packet;
radiopacket_t rx_packet;

volatile uint8_t rxflag = 0;

bool transmit_packet() {
#ifdef DEBUG
	UART_print(UART_CH_0, "Tx ... ");
#endif
	// Transmit packet
	if (Radio_Transmit(&tx_packet, RADIO_WAIT_FOR_TX) == RADIO_TX_MAX_RT) {
#ifdef DEBUG
		UART_print(UART_CH_0, "Fail\n");
#endif
		return false;
	} else {
#ifdef DEBUG
		UART_print(UART_CH_0, "Success\n");
#endif
		return true;
	}
}

void transmit_roomba_heading_reply(ROOMBA_NUMBER roomba, int16_t angle) {
	Radio_Set_Tx_Addr(roomba_addr[roomba]);

	tx_packet.type = PACKET_HEADING_REPLY;
	tx_packet.payload.heading_reply.roomba_id = roomba;
	tx_packet.payload.heading_reply.theta = angle;

#ifdef DEBUG
	UART_print(UART_CH_0, "Heading reply ");
#endif

	// Keep trying! Critical packet!
	while (!transmit_packet())
		;
}

// Returns the picked heading/angle
int16_t pick_heading(ROOMBA_NUMBER roomba) {
	// TODO: use multiple roombas and use Least recently visited algorithm?

//	// for now just pick biggest distance
//	int i;
//	int16_t largest_distance = -1;
//	int16_t heading = 0;
//	for (i = 0; i < SONAR_NUM_DATA_POINTS; i++) {
//		if (data_points[i][3] > largest_distance || data_points[i][3] == -10) {
//			largest_distance = data_points[i][3];
//			heading = data_points[i][2];
//		}
//	}

	// Biggest "chunck" of -10s (indicating unknown area)
	int i;
	int16_t heading = 0;
	int8_t chunk_start = -1;
	int8_t chunk_length = 0;

	// Storing the chunks, [0] = index, [1] = length
	int8_t chunks[8][2];
	int8_t num_chunks = 0;

	for (i = 0; i < SONAR_NUM_DATA_POINTS; i++) {
		if (data_points[i][3] == -10) {
			if (chunk_start == -1) {
				// Not in chunk, start a new one
				chunk_start = i;
				UART_print(UART_CH_0, " - start %d\n", i);
				chunk_length++;
				num_chunks++;
			} else {
				// Continuing chunk
				UART_print(UART_CH_0, " - continue %d\n", i);
				chunk_length++;
			}
		} else if (chunk_start != -1) {
			// Save the chunk
			UART_print(UART_CH_0, " - save %d\n", i);
			chunks[num_chunks - 1][0] = chunk_start;
			chunks[num_chunks - 1][1] = chunk_length;
			// Re-init for a new chunk
			chunk_start = -1;
			chunk_length = 0;
		}
	}

	// Find largest chunk
	int8_t largest_chunk_len = -1;
	int8_t chunk_index = -1;
	int8_t chunk_num = -1;
	UART_print(UART_CH_0, "num chuncks: %d\n", num_chunks);
	for (i = 0; i < num_chunks; i++) {
		if (chunks[i][1] > largest_chunk_len) {
			largest_chunk_len = chunks[i][1];
			UART_print(UART_CH_0, "chunk size: %d\n", largest_chunk_len);
			chunk_index = chunks[i][0] + chunks[i][1] / 2;
			chunk_num = i;
			heading = data_points[chunk_index][2];
		}
	}

#ifdef DEBUG
	UART_print(UART_CH_0, "TURN TO: %d\n", heading);
	UART_print(UART_CH_0, "Chunk #%d, idx: %d, len: %d\n", chunk_num, chunk_index, largest_chunk_len);
#endif
	return heading;
}

void receive_task() {
	for (;;) {
		// The rxflag is set by radio_rxhandler function below indicating that a
		// new packet is ready to be read.
		if (rxflag) {
			// Receive packet.
			if (Radio_Receive(&rx_packet) != RADIO_RX_MORE_PACKETS) {
				// if there are no more packets on the radio, clear the receive flag;
				// otherwise, we want to handle the next packet on the next loop iteration.
				rxflag = 0;
			}

			static pf_position_t pos;
			static pf_sonar_t sonar;
			uint8_t roomba_id;

			switch (rx_packet.type) {
				case PACKET_POSITION:
#ifdef DEBUG
					UART_print(UART_CH_0, "Rx position packet\n");
#endif
					pos = rx_packet.payload.position;
					android_send_position_data(pos.roomba_id, pos.delta_x, pos.delta_y, pos.alpha);
					// FIXME below for multiple roombas
					roomba_pos[0] += pos.delta_x;
					roomba_pos[1] += pos.delta_y;
					break;
				case PACKET_SONAR:
#ifdef DEBUG
					UART_print(UART_CH_0, "Rx sonar packet\n");
#endif
					sonar = rx_packet.payload.sonar;
					if (sonar.distance != -10) {
						android_send_sonar_data(sonar.roomba_id, sonar.theta, sonar.distance);
					}
					UART_print(UART_CH_0, "theta: %d, d: %d\n", sonar.theta, sonar.distance);
					// TODO: temporary below!
					data_points[data_point_index][0] = roomba_pos[0] + sin(((double) sonar.theta) * 3.141592 / 180.0) * sonar.distance;
					data_points[data_point_index][1] = roomba_pos[1] + cos(((double) sonar.theta) * 3.141592 / 180.0) * sonar.distance;
					data_points[data_point_index][2] = sonar.theta;
					data_points[data_point_index][3] = sonar.distance;
					data_point_index = (data_point_index + 1) % SONAR_NUM_DATA_POINTS;
					break;
				case PACKET_HEADING_REQUEST:
#ifdef DEBUG
					UART_print(UART_CH_0, "Rx heading req\n");
#endif
					roomba_id = rx_packet.payload.heading_req.roomba_id;
					_delay_ms(25);
					transmit_roomba_heading_reply(roomba_id, pick_heading(roomba_id));
					break;
				case PACKET_BUMP:
#ifdef DEBUG
					UART_print(UART_CH_0, "Rx bump\n");
#endif
					android_send_bump_data(rx_packet.payload.bump.roomba_id);
					break;
				default:
#ifdef DEBUG
					UART_print(UART_CH_0, "Rx unknown packet type\n");
#endif
					break;
			}
		}
	}
}

void radio_rxhandler(uint8_t pipenumber) {
	rxflag = 1;
}

void main() {
#ifdef DEBUG
	UART_Init(UART_CH_0, 57600);
	UART_print(UART_CH_0, "boot\n");
#endif
	// Bluetooth connection
	UART_Init(UART_CH_1, 9600);

	Task_Create_System(receive_task, 0);

	Radio_Init();
	Radio_Configure_Rx(RADIO_PIPE_0, base_station_addr, ENABLE);
	Radio_Configure(RADIO_1MBPS, RADIO_HIGHEST_POWER);
}
