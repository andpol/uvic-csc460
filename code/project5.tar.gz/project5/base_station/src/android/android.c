/*
 * android.c
 *
 *  Created on: Aug 17, 2013
 *      Author: andpol
 */

#include "android.h"

void android_send_position_data(uint8_t roomba_id, int16_t delta_x, int16_t delta_y, int16_t alpha) {
	UART_print(ANDROID_BT_UART_CHANNEL, "p,%d,%d,%d,%d\n", roomba_id, delta_x, delta_y, alpha);
}
void android_send_sonar_data(uint8_t roomba_id, int16_t theta, int16_t distance) {
	UART_print(ANDROID_BT_UART_CHANNEL, "s,%d,%d,%d\n", roomba_id, theta, distance);
}
void android_send_bump_data(uint8_t roomba_id) {
	UART_print(ANDROID_BT_UART_CHANNEL, "b,%d\n", roomba_id);
}

