/*
 * android.h
 *
 *  Created on: Aug 17, 2013
 *      Author: andpol
 */

#ifndef ANDROID_H_
#define ANDROID_H_

#include "../uart/BlockingUART.h"

#define ANDROID_BT_UART_CHANNEL UART_CH_1

void android_send_position_data(uint8_t roomba_id, int16_t delta_x, int16_t delta_y, int16_t alpha);
void android_send_sonar_data(uint8_t roomba_id, int16_t theta, int16_t distance);
void android_send_bump_data(uint8_t roomba_id);

#endif /* ANDROID_H_ */
