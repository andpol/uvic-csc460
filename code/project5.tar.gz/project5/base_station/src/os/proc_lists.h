/*
 * linked_list.h
 *
 *  Created on: Jul 7, 2013
 *      Author: andpol
 */

#ifndef LINKED_LIST_H_
#define LINKED_LIST_H_

#include <stdlib.h>
#include <avr/common.h>

#include "error.h"
#include "os.h"

typedef enum {
	RUNNING, // Process is currently running
	BLOCKED, // Process is blocked by an event
	READY,   // Process is ready to run
	DEAD,	 // Process has not yet been allocated and does not have a SP
} process_state_t;

typedef struct d_struct process_descriptor_t;
struct d_struct {
	// The stack for the process
	uint8_t stack[MAXSTACK];
	// Pointer to the HW stack pointer
	volatile uint8_t sp[3];
	// Process ID
	uint8_t pid;
	// Type (IDLE, SYSTEM, PERIODIC, or RR)
	uint8_t type;
	// Argument passed by the init function
	int arg;
	// The current state of the process
	process_state_t state;
	// The remaining number of ticks for the process
	uint8_t ticks_remaining;
	// The tick number for when the next
	uint32_t next_start;
	// The period of the process (in ticks) (only used for PERIODIC procs)
	uint32_t period;
	// The worst case execution time of the process (in ticks) (only used for PERIODIC procs)
	uint32_t wcet;
	// A pointer to the next item in the linked list (or NULL if none)
	process_descriptor_t * next;
};

typedef struct {
	uint8_t len;
	process_descriptor_t * head;
	process_descriptor_t * tail;
} proc_list_t;

proc_list_t system_procs;
proc_list_t periodic_procs;
proc_list_t rr_procs;
proc_list_t waiting_procs;
process_descriptor_t * idle_proc;

void proc_list_init(proc_list_t * list) {
	list->head = list->tail = NULL;
	list->len = 0;
}

void proc_list_append(proc_list_t * list, process_descriptor_t * proc) {
	if (list->len == 0) {
		list->head = list->tail = proc;
	} else {
		list->tail->next = proc;
	}
	list->tail = proc;
	proc->next = NULL;
	list->len++;
}

process_descriptor_t * proc_list_pop(proc_list_t * list) {
	if (list->len == 0) {
		return NULL;
	} else if (list->len == 1) {
		process_descriptor_t * p = list->head;
		list->head = list->tail = NULL;
		list->len = 0;
		return p;
	} else {
		process_descriptor_t * p = list->head;
		list->head = p->next;
		list->len--;
		return p;
	}
}

process_descriptor_t * proc_list_peek(proc_list_t * list) {
	return list->head;
}

void proc_list_insert_into_offset_order(proc_list_t * list, process_descriptor_t * proc) {
	if (list->len == 0) {
		list->head = list->tail = proc;
	} else {
		process_descriptor_t * p = list->head;
		process_descriptor_t * p_prev = NULL;
		while (p != NULL && p->next_start < proc->next_start) {
			p_prev = p;
			p = p->next;
		}

		if (p_prev == NULL) {
			// Insert as first element in list
			list->head = proc;
			proc->next = p;
		} else if (p == NULL) {
			// Insert as last element in list
			list->tail = proc;
			p_prev->next = proc;
			proc->next = NULL;
		} else {
			// Somewhere in the middle, insert between p_prev and p
			p_prev->next = proc;
			proc->next = p;
		}
	}
	list->len++;
}

process_descriptor_t * proc_list_pop_first(proc_list_t * list, process_state_t state) {
	process_descriptor_t * p;
	if (list->len == 0) {
		p = NULL;
	} else if (list->len == 1) {
		p = list->head;
		list->len = 0;
		list->head = list->tail = NULL;
	} else {
		process_descriptor_t * p_prev = NULL;
		p = list->head;
		while (p != NULL && p->state != state) {
			p_prev = p;
			p = p->next;
		}
		if (p_prev == NULL) {
			// First element in list
			list->head = p->next;
		} else if (p == NULL) {
			// Last element in list
			list->tail = p_prev;
		} else {
			// Somewhere in the middle
			p_prev->next = p->next;
		}
		p->next = NULL;
	}

	return p;
}

#endif /* LINKED_LIST_H_ */
