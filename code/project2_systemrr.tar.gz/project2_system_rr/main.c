/*
 * main.c
 *
 *  Created on: Jun 23, 2013
 *      Author: andpol
 *
 */

#include "os.h"
#include "PIR.h"
#include "Sonar.h"
#include "Roomba.h"
#include "BlockingUART.h"

#include <avr/io.h>
#include <stdbool.h>

#define NUM_TICKS_INTRUDER_TIMEOUT 1000
#define TURN_VELOCITY 100
#define DRIVE_VELOCITY 200
#define SONAR_EPSILON 5
#define FOLLOW_DISTANCE 100

typedef enum {
	DRIVE_FORWARDS = 1, DRIVE_REVERSE, DRIVE_LEFT, DRIVE_RIGHT, DRIVE_STOP,
} DRIVE_OPTIONS;

typedef enum {
	PATROLLING, INTRUDER_DETECTED,
} FSM;

FSM fsm = PATROLLING;

// Latest sensor readings
bool are_you_there = false;
int distance = FOLLOW_DISTANCE;
ROOMBA_PACKET_1 roomba_sensor_data;

const unsigned int PT = 0;
const unsigned char PPP[] = { };

// SYSTEM LEVEL TASK
void S_TASK_sonar_ping() {
	distance = (distance + get_sonar_distance()) / 2;
}

// SYSTEM LEVEL TASK
void S_TASK_roomba_sensor_query() {
	roomba_sensor_data = roomba_sense_1();
}

// SYSTEM LEVEL TASK
void S_TASK_roomba_drive() {
	DRIVE_OPTIONS opt = Task_GetArg();
	switch (opt) {
		case DRIVE_FORWARDS:
			roomba_drive(DRIVE_VELOCITY, RADIUS_STRAIGHT);
			break;
		case DRIVE_REVERSE:
			roomba_drive(-DRIVE_VELOCITY, RADIUS_STRAIGHT);
			break;
		case DRIVE_LEFT:
			roomba_drive(TURN_VELOCITY, 1);
			break;
		case DRIVE_RIGHT:
			roomba_drive(TURN_VELOCITY, -1);
			break;
		case DRIVE_STOP:
			roomba_drive(0, RADIUS_STRAIGHT);
			break;
		default:
			// NOP
			break;
	}
}

void RR_TASK_pir_check() {
	for (;;) {
		are_you_there = get_PIR_state();
	}
}

void RR_TASK_fsm_transition() {
	static unsigned int intruder_detect_timestamp;
	for (;;) {
		if (are_you_there) {
			// If the PIR is triggered, go into the INTRUDER_DETECTED state
			fsm = INTRUDER_DETECTED;
			intruder_detect_timestamp = Now();
		} else if (fsm == INTRUDER_DETECTED) {
			unsigned int delta = Now() - intruder_detect_timestamp;
			if (delta >= NUM_TICKS_INTRUDER_TIMEOUT || roomba_sensor_data.virtual_wall) {
				fsm = PATROLLING;
			}
		}
	}
}
void RR_TASK_adjust_movement() {
	static bool in_virtual_wall = false;
	for (;;) {
		if (fsm == PATROLLING) {
			Task_Create(S_TASK_roomba_sensor_query, 0, SYSTEM, 0);
			if (roomba_sensor_data.bumps_wheeldrops & 2) {
				// Turn Right
				Task_Create(S_TASK_roomba_drive, DRIVE_RIGHT, SYSTEM, 0);
			} else if (roomba_sensor_data.bumps_wheeldrops & 1) {
				// Turn Left
				Task_Create(S_TASK_roomba_drive, DRIVE_LEFT, SYSTEM, 0);
			} else if (roomba_sensor_data.virtual_wall) {
				if (!in_virtual_wall) {
					// Turn Left
					Task_Create(S_TASK_roomba_drive, DRIVE_LEFT, SYSTEM, 0);
					in_virtual_wall = true;
				}
			} else {
				// No relevant sensors triggered, drive straight
				Task_Create(S_TASK_roomba_drive, DRIVE_FORWARDS, SYSTEM, 0);
				in_virtual_wall = false;
			}
		} else if (fsm == INTRUDER_DETECTED) {
			Task_Create(S_TASK_sonar_ping, 0, SYSTEM, 0);
			// Too close
			if (distance < FOLLOW_DISTANCE - SONAR_EPSILON) {
				Task_Create(S_TASK_roomba_drive, DRIVE_REVERSE, SYSTEM, 0);
			}
			// Too far
			else if (distance > FOLLOW_DISTANCE + SONAR_EPSILON) {
				Task_Create(S_TASK_roomba_drive, DRIVE_FORWARDS, SYSTEM, 0);
			}
			// Stay still
			else {
				Task_Create(S_TASK_roomba_drive, DRIVE_STOP, SYSTEM, 0);
			}
		}
	}
}

int r_main() {
	// LED
	DDRB |= _BV(PB0);

//	UART_Init0(57600);
	init_PIR();
	init_sonar();
	init_roomba();

	_delay_ms(200);

	Task_Create(RR_TASK_pir_check, 0, RR, 0);
	Task_Create(RR_TASK_fsm_transition, 0, RR, 0);
	Task_Create(RR_TASK_adjust_movement, 0, RR, 0);

	return 0;
}
