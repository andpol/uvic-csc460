package org.uvic.roombamapping;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.util.FloatMath;
import android.view.MotionEvent;
import android.view.View;

public class MapView extends View {
    static final Paint redPaint;
    static final Paint bluePaint;

    static {
        redPaint = new Paint();
        redPaint.setColor(0xFF0000);
        redPaint.setStrokeWidth(20);
        redPaint.setAlpha(160);
        redPaint.setStrokeCap(Paint.Cap.ROUND);

        bluePaint = new Paint();
        bluePaint.setColor(0x0000FF);
        bluePaint.setStrokeWidth(20);
        bluePaint.setAlpha(160);
        bluePaint.setStrokeCap(Paint.Cap.ROUND);

    }

    private static final float MAX_FINGER_DRAG_TAP = 10f;
    private static final float MIN_FINGER_DIST = 10f;
    private static final float MIN_ROTATE_ANGLE = 0.1f;
    private final Floorplan floorplan;
    PointF start = new PointF();
    // Matrices for translation, scaling, and rotation
    Matrix matrix = new Matrix();
    Matrix savedMatrix = new Matrix();
    Matrix rotMatrix = new Matrix();
    // State variables for the touch interface
    TouchState state;
    float oldDist = 1f;
    float oldAngle = 0f;
    PointF mid = new PointF();

    public MapView(Floorplan floorplan, Context context) {
        super(context);
        this.floorplan = floorplan;

        // Initialize the scale so we can use mm for canvas units
        matrix.postScale(0.5f, 0.5f, 0, 0);
        matrix.postTranslate(getWidth() / 2, -getHeight() / 2);
    }

    public boolean onTouchEvent(MotionEvent event) {

        switch (event.getAction() & MotionEvent.ACTION_MASK) {
            case MotionEvent.ACTION_DOWN:
                // When the first finger is touched to the screen
                savedMatrix.set(matrix);
                start.set(event.getX(), event.getY());
                state = TouchState.ONE;
                break;
            case MotionEvent.ACTION_UP:
                if (distance(start, new PointF(event.getX(), event.getY())) <= MAX_FINGER_DRAG_TAP) {
                    Matrix inverse = new Matrix();
                    matrix.invert(inverse);
                    float[] pos = new float[]{event.getX(), event.getY()};
                    inverse.mapPoints(pos);
                }
                // Fall Through: when any finger is lifted from the screen
            case MotionEvent.ACTION_POINTER_UP:
                rotMatrix.reset();
                // If only one pointer remaining (the 2 is NOT a typo)
                if (event.getPointerCount() == 2) {
                    savedMatrix.set(matrix);
                    // Set the start point based on which finger was removed (use the other one)
                    if (event.getAction() >> MotionEvent.ACTION_POINTER_INDEX_SHIFT == 0)
                        start.set(event.getX(1), event.getY(1));
                    else
                        start.set(event.getX(0), event.getY(0));
                    state = TouchState.ONE;
                } else {
                    savedMatrix.set(matrix);
                    start.set(event.getX(), event.getY());
                    state = TouchState.NONE;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                // When a finger moves across the screen
                if (state == TouchState.ONE) {
                    matrix.set(savedMatrix);
                    matrix.postTranslate(event.getX() - start.x, event.getY() - start.y);
                } else if (state == TouchState.TWO) {
                    // Deal with scaling
                    float newDist = spacing(event);
                    if (newDist > MIN_FINGER_DIST) {
                        matrix.set(savedMatrix);
                        float scale = newDist / oldDist;
                        matrix.postScale(scale, scale, mid.x, mid.y);
                    }
                    // Deal with rotation
                    float newAngle = angle(event);
                    float dAngle = newAngle - oldAngle;
                    if (Math.abs(dAngle) > MIN_ROTATE_ANGLE) {
                        rotMatrix.postRotate(dAngle, mid.x, mid.y);
                        oldAngle = newAngle;
                    }
                }
                break;
            case MotionEvent.ACTION_POINTER_DOWN:
                rotMatrix.reset();
                // When the second finger is touched to the screen
                oldDist = spacing(event);
                oldAngle = angle(event);
                if (oldDist > MIN_FINGER_DIST) {
                    savedMatrix.set(matrix);
                    midPoint(mid, event);
                    state = TouchState.TWO;
                }
                break;
        }

        // Apply any rotations
        matrix.postConcat(rotMatrix);

        // Redraw the entire view
        invalidate();

        // Return value of true indicates event was handled
        return true;
    }

    /**
     * Calculates the distance between first and second finger for specified MotionEvent
     */
    private float spacing(MotionEvent event) {
        return distance(new PointF(event.getX(0), event.getY(0)), new PointF(event.getX(1), event.getY(1)));
    }

    /**
     * Calculates the distance between two points
     */
    private float distance(PointF p0, PointF p1) {
        float dx = p1.x - p0.x;
        float dy = p1.y - p0.y;
        return FloatMath.sqrt(dx * dx + dy * dy);
    }

    /**
     * Takes a MotionEvent and returns the angle (in degrees) between fingers 0 and 1 NOTE: (zero degrees changes based on which finger was first)
     */
    private float angle(MotionEvent event) {
        // Get the dx and dy distances between first and second finger
        float x = event.getX(0) - event.getX(1);
        float y = event.getY(0) - event.getY(1);
        return (float) (Math.atan2(y, x) * 180f / Math.PI);
    }

    private void midPoint(PointF point, MotionEvent event) {
        float x = event.getX(0) + event.getX(1);
        float y = event.getY(0) + event.getY(1);
        point.set(x / 2, y / 2);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.save();
        canvas.concat(matrix);
        // Flip the coordinate system so pos Y is up, pos X is right
        canvas.scale(1, -1);

        // Draw all the Roombas
        for (Roomba roomba : floorplan.getRoombas()) {
            roomba.draw(canvas);
        }

        // Draw all the sonar data points
        for (SonarDataPoint point : floorplan.getSonarDataPoints()) {
            point.draw(canvas);
        }

        // Draw all the bump data points
        for (BumpDataPoint point : floorplan.getBumpDataPoints()) {
            point.draw(canvas);
        }

        // Draw the coordinate axis
        canvas.drawLine(-150, 0, 150, 0, bluePaint); // Horizontal line
        canvas.drawLine(0, -150, 0, 150, redPaint); // Arrow line
        canvas.drawLine(0, 150, 50, 100, redPaint);
        canvas.drawLine(0, 150, -50, 100, redPaint);

        canvas.restore();
    }

    // Possible MapView states:
    enum TouchState {
        NONE, ONE, TWO
    }
}
