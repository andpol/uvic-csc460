package org.uvic.roombamapping;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.util.UUID;

public class RoombaBluetooth {

    // UUID for Bluetooth Serial Port Profile: http://developer.android.com/reference/android/bluetooth/BluetoothDevice.html#createRfcommSocketToServiceRecord%28java.util.UUID%29
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private final Floorplan floorplan;
    private final String bluetooth_pairing_name;
    private BluetoothDevice device;
    private BluetoothSocket btSocket;
    private InputStream roombaInputStream;
    private BluetoothReaderTask readerTask;

    public RoombaBluetooth(Floorplan floorplan, String bluetooth_pairing_name) {
        this.floorplan = floorplan;
        this.bluetooth_pairing_name = bluetooth_pairing_name;

    }

    /**
     * Connect to the Roomba device.
     *
     * @return true if successful, false if already connected or unsuccessful
     */
    public boolean connect() {
        if (device != null) {
            // Already connected
            return false;
        }

        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            Toast.makeText(floorplan.getApplicationContext(), "Bluetooth not supported on device.", Toast.LENGTH_LONG).show();
            return false;
        }
        if (!adapter.isEnabled()) {
            Toast.makeText(floorplan.getApplicationContext(), "Bluetooth not enabled.", Toast.LENGTH_LONG).show();
            return false;
        }
        for (BluetoothDevice dev : adapter.getBondedDevices()) {
            if (dev.getName().equals(bluetooth_pairing_name)) {
                device = dev;
                Toast.makeText(floorplan.getApplicationContext(), "Connected to: " + dev.getAddress(), Toast.LENGTH_SHORT).show();
                break;
            }
        }
        if (device == null) {
            Toast.makeText(floorplan.getApplicationContext(), "Could not find '" + bluetooth_pairing_name + "'", Toast.LENGTH_LONG).show();
            return false;
        }

        // Get a Bluetooth Socket to connect with the given BluetoothDevice
        try {
            btSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);
        } catch (IOException e) {
            Toast.makeText(floorplan.getApplicationContext(), "ERROR: " + e.toString(), Toast.LENGTH_LONG).show();
            return false;
        }
        try {
            btSocket.connect();
            roombaInputStream = btSocket.getInputStream();
        } catch (IOException e) {
            Toast.makeText(floorplan.getApplicationContext(), "ERROR: " + e.toString(), Toast.LENGTH_LONG).show();
            return false;
        }

        // Start an asyncronous task to constantly read from the bluetooth input stream
        readerTask = new BluetoothReaderTask();
        readerTask.execute();

        return true;
    }

    /**
     * Disconnect to the Roomba device.
     *
     * @return true if successful, false if not connected or unsuccessful
     */
    public boolean disconnect() {
        if (device == null) {
            Toast.makeText(floorplan.getApplicationContext(), "Device not open", Toast.LENGTH_LONG).show();
            return false;
        }

        readerTask.cancel(true);

        try {
            roombaInputStream.close();
            btSocket.close();
            device = null;
        } catch (IOException e) {
            Toast.makeText(floorplan.getApplicationContext(), "ERROR: " + e.toString(), Toast.LENGTH_LONG).show();
            return false;
        }

        return true;
    }

    /**
     * @return true if connected to a Roomba
     */
    public boolean isConnected() {
        return device != null;
    }

    /**
     * Process a ASCII roomba position packet
     *
     * @param data the packet data in the following format:
     *             data[0] = 'p' <- packet identifier: the letter 's' followed by a comma
     *             data[1] = roomba id,
     *             data[2] = delta X,
     *             data[3] = delta Y,
     *             data[4] = alpha
     */
    private void processPositionPacket(String[] data) {
        if (data.length != 5) {
            throw new IllegalArgumentException("Position packet incorrect length: " + data.length + " Data: " + data.toString());
        }

        int id = Integer.parseInt(data[1]);
        int delta_x = Integer.parseInt(data[2]);
        int delta_y = Integer.parseInt(data[3]);
        int alpha = Integer.parseInt(data[4]);

        // Get or create the roomba instance
        Roomba roomba = floorplan.getRoomba(id);
        if (roomba == null) {
            roomba = new Roomba(id, delta_x, delta_y, alpha);
            floorplan.addRoomba(id, roomba);
        } else {
            roomba.updatePosition(delta_x, delta_y, alpha);
        }
    }

    /**
     * Process a ASCII sonar packet
     *
     * @param data the packet data in the following format:
     *             data[0] = 's' <- packet identifier: the letter 's' followed by a comma
     *             data[1] = roomba id,
     *             data[2] = theta, <- in the range [-90, 90]
     *             data[3] = distance
     */
    private void processSonarPacket(String[] data) {
        if (data.length != 4) {
            throw new IllegalArgumentException("Position packet incorrect length: " + data.length + " Data: " + data.toString());
        }

        int roomba_id = Integer.parseInt(data[1]);
        Roomba roomba = floorplan.getRoomba(roomba_id);
        if (roomba == null) {
            // Can't do anything here, maybe we connected mid stream?
            return;
        }
        int theta = Integer.parseInt(data[2]);
        int distance = Integer.parseInt(data[3]);

        // The sonar point position, relative to the roomba position and heading
        double pX = Math.sin(Math.toRadians(theta + roomba.getHeading())) * distance;
        double pY = Math.cos(Math.toRadians(theta + roomba.getHeading())) * distance;

        floorplan.addDataPoint(new SonarDataPoint(roomba.getX() + (long) pX, roomba.getY() + (long) pY));
    }

    /**
     * Process a ASCII bump packet
     *
     * @param data the packet data in the following format:
     *             data[0] = 'b' <- packet identifier: the letter 's' followed by a comma
     *             data[1] = roomba id,
     */
    private void processBumpPacket(String[] data) {
        if (data.length != 2) {
            throw new IllegalArgumentException("Position packet incorrect length: " + data.length + " Data: " + data.toString());
        }

        int roomba_id = Integer.parseInt(data[1]);
        Roomba roomba = floorplan.getRoomba(roomba_id);
        if (roomba == null) {
            // Can't do anything here, maybe we connected mid stream?
            return;
        }
        // The sonar point position, relative to the roomba position and heading
        double pX = Math.sin(Math.toRadians(roomba.getHeading())) * Roomba.RADIUS;
        double pY = Math.cos(Math.toRadians(roomba.getHeading())) * Roomba.RADIUS;

        floorplan.addBumpDataPoint(new BumpDataPoint(roomba.getX() + (long) pX, roomba.getY() + (long) pY));
    }

    private enum PACKET_TYPE {
        POSITION_PACKET('p'),
        SONAR_PACKET('s'),
        BUMP_PACKET('b');
        public final char identifier;

        PACKET_TYPE(char identifier) {
            this.identifier = identifier;
        }
    }

    private class BluetoothReaderTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... params) {
            StringBuffer buffer = new StringBuffer();
            PACKET_TYPE packet_type = null;
            while (!isCancelled()) {
                try {
                    int b = roombaInputStream.read();
                    if (b == -1) {
                        Log.d(floorplan.getApplicationContext().getString(R.string.app_name), "Read -1 from BT input stream");
                        return null;
                    }
                    buffer.append((char) b);
                    if (buffer.length() == 1) {
                        // Start of ASCII packet
                        if (buffer.charAt(0) == PACKET_TYPE.POSITION_PACKET.identifier) {
                            packet_type = PACKET_TYPE.POSITION_PACKET;
                        } else if (buffer.charAt(0) == PACKET_TYPE.SONAR_PACKET.identifier) {
                            packet_type = PACKET_TYPE.SONAR_PACKET;
                        } else if (buffer.charAt(0) == PACKET_TYPE.BUMP_PACKET.identifier) {
                            packet_type = PACKET_TYPE.BUMP_PACKET;
                        } else {
                            packet_type = null;
                            Log.e(floorplan.getApplicationContext().getString(R.string.app_name), "Invalid packet char: " + buffer.charAt(0));
                        }
                    } else if (buffer.charAt(buffer.length() - 1) == '\n') {
                        // End of ASCII packet
                        String[] data = buffer.toString().split(",|\\n");
                        switch (packet_type) {
                            case POSITION_PACKET:
                                processPositionPacket(data);
                                break;
                            case SONAR_PACKET:
                                processSonarPacket(data);
                                break;
                            case BUMP_PACKET:
                                processBumpPacket(data);
                                break;
                            default:
                                // NOP - can't do anything with invalid packet
                                break;
                        }
                        // Re-initialize for next ASCII packet
                        buffer.setLength(0);
                        packet_type = null;
                        publishProgress();
                    }

                } catch (IOException e) {
                    Log.e(floorplan.getApplicationContext().getString(R.string.app_name), e.getMessage());
                }
            }
            return null;
        }

        @Override
        protected void onProgressUpdate(Void... values) {
            floorplan.refreshView();
        }
    }

}
