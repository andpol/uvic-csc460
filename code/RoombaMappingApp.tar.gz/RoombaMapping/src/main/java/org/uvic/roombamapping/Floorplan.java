package org.uvic.roombamapping;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Floorplan extends Activity {
    private final RoombaBluetooth baseStation;
    // Floorplan from ID -> Roomba
    private final Map<Integer, Roomba> roombas;
    private final Collection<SonarDataPoint> sonarDataPoints;
    private final Collection<BumpDataPoint> bumpDataPoints;
    private MapView view;

    public Floorplan() {
        this.sonarDataPoints = new ArrayList<SonarDataPoint>();
        this.bumpDataPoints = new ArrayList<BumpDataPoint>();
        this.roombas = new HashMap<Integer, Roomba>();
        baseStation = new RoombaBluetooth(this, "linvor");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        view = new MapView(this, getApplicationContext());
        setContentView(view);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.map, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_connect:
                if (!baseStation.isConnected()) {
                    if (baseStation.connect()) {
                        // Successful connection
                        item.setTitle(R.string.action_disconnect);
                    }
                } else {
                    if (baseStation.disconnect()) {
                        // Successful disconnection
                        item.setTitle(R.string.action_connect);
                    }
                }
                return true;
            default:
                return false;
        }

    }

    Collection<Roomba> getRoombas() {
        synchronized (roombas) {
            return new ArrayList<Roomba>(roombas.values());
        }
    }

    Collection<SonarDataPoint> getSonarDataPoints() {
        synchronized (sonarDataPoints) {
            return new ArrayList<SonarDataPoint>(sonarDataPoints);
        }
    }

    Collection<BumpDataPoint> getBumpDataPoints() {
        synchronized (bumpDataPoints) {
            return new ArrayList<BumpDataPoint>(bumpDataPoints);
        }
    }

    void addRoomba(int id, Roomba roomba) {
        synchronized (roombas) {
            this.roombas.put(id, roomba);
        }
    }

    Roomba getRoomba(int id) {
        synchronized (roombas) {
            return roombas.get(id);
        }
    }

    void addDataPoint(SonarDataPoint sonarDataPoint) {
        synchronized (sonarDataPoints) {
            this.sonarDataPoints.add(sonarDataPoint);
        }
    }

    void addBumpDataPoint(BumpDataPoint bumpDataPoint) {
        synchronized (bumpDataPoints) {
            this.bumpDataPoints.add(bumpDataPoint);
        }
    }

    void refreshView() {
        view.invalidate();
    }
}
