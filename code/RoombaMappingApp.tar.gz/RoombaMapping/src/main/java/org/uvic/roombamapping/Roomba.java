package org.uvic.roombamapping;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.Log;

/**
 * Created by andpol on 8/17/13.
 */
public class Roomba {
    /**
     * Radius of the drawn roomba, in mm *
     */
    public static final float RADIUS = 330f / 2;
    private static final Paint yellow;
    private static final Paint black;

    static {
        yellow = new Paint();
        yellow.setColor(0xFFD700);
        yellow.setAlpha(255);

        black = new Paint();
        black.setColor(0x000000);
        black.setAlpha(255);
        black.setStrokeWidth(10);
        black.setStrokeCap(Paint.Cap.ROUND);
        black.setTextSize(50);
    }

    /**
     * X coordinate, in mm.
     */
    private long x;
    /**
     * Y coordinate, in mm.
     */
    private long y;
    /**
     * Heading of the roomba, in degrees, relative to NORTH aka Positive Y, CW is positive, CCW is negative.
     */
    private int heading;
    /**
     * ID of the roomba
     */
    private int id;

    Roomba(int id, long x, long y, int heading) {
        this.id = id;
        this.x = x;
        this.y = y;
        this.heading = heading;
    }

    void updatePosition(long deltaX, long deltaY, int heading) {
        // Update heading
        this.heading += heading;
        // Calculate new position
        this.x += Math.sin(Math.toRadians(this.heading)) * deltaY;
        this.y += Math.cos(Math.toRadians(this.heading)) * deltaY;
        this.x += Math.sin(Math.toRadians(this.heading - 90)) * deltaX;
        this.y += Math.cos(Math.toRadians(this.heading - 90)) * deltaX;
    }

    public long getX() {
        return x;
    }

    public long getY() {
        return y;
    }

    public int getHeading() {
        return heading;
    }

    public void draw(Canvas canvas) {
        canvas.drawCircle(x, y, RADIUS, yellow);
        // Arrow pointing in direction of roomba
        canvas.save();
        canvas.translate(x, y);
        canvas.rotate(-heading);
        Log.d("Roomba Mapping", "HEADING: " + heading);
        canvas.drawLine(0, RADIUS, 0, -RADIUS, black);
        canvas.drawLine(0, RADIUS, 100, RADIUS - 100, black);
        canvas.drawLine(0, RADIUS, -100, RADIUS - 100, black);
        canvas.restore();

//        // Path for drawing text
//        Path p = new Path();
//        p.moveTo(x, y - RADIUS);
//        p.lineTo(x, y + RADIUS);
//        // Flip the Y axis
//        canvas.save();
//        canvas.scale(1, -1);
//        canvas.drawTextOnPath("Roomba #" + id, p, 0, -30, black);
//        canvas.restore();
    }
}
