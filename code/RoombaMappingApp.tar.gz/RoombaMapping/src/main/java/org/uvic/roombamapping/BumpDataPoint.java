package org.uvic.roombamapping;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Created by andpol on 8/17/13.
 */
public class BumpDataPoint {
    /** Radius of the point, in mm **/
    private static final float RADIUS = 30f;

    BumpDataPoint(long x, long y) {
        this.x = x;
        this.y = y;
    }

    private static final Paint red;
    static {
        red = new Paint();
        red.setColor(0xFF0000);
        red.setAlpha(200);
    }

    /**
     * X coordinate, in mm.
     */
    private long x;
    /**
     * Y coordinate, in mm.
     */
    private long y;

    public void draw(Canvas canvas) {
        canvas.drawCircle(x, y, RADIUS, red);
    }
}
