package org.uvic.roombamapping;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * Created by andpol on 8/17/13.
 */
public class SonarDataPoint {
    /** Radius of the point, in mm **/
    private static final float RADIUS = 25f;

    SonarDataPoint(long x, long y) {
        this.x = x;
        this.y = y;
    }

    private static final Paint black;
    static {
        black = new Paint();
        black.setColor(0x000000);
        black.setAlpha(200);
    }

    /**
     * X coordinate, in mm.
     */
    private long x;
    /**
     * Y coordinate, in mm.
     */
    private long y;

    public void draw(Canvas canvas) {
        canvas.drawCircle(x, y, RADIUS, black);
    }
}
