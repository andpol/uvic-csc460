/*
 * Sonar.h
 *
 *  Created on: May 17, 2013
 *      Author: andpol
 *
 *		Timer:
 *		Sonar uses TIMER1
 *
 *      Wiring:
 *       - Sonar[PW] -> PD4
 *       - Sonar[RX] pin left unconnected for continous ranging
 */

#ifndef SONAR_H_
#define SONAR_H_

#include <avr/interrupt.h>
#include <avr/io.h>

// DELTA_MULTIPLIER =  64 (prescaler) * 34029 (cm/s) / 16'000'000 (CPU freq) / 2 (there and back again time)
#define DELTA_MULTIPLIER 0.068058

void (*_ping_response_callback)(int distance);

inline void _start_timer() {
	TCNT1 = 0;
	// Enable input capture interrupts
	TIMSK1 |= _BV(ICIE1);
	// Start timer using a prescaler of 64
	TCCR1B |= (3 << CS10);
}

inline void _stop_timer() {
	// Disable input capture interrupts
	TIMSK1 &= ~_BV(ICIE1);
	// Set the timer to have "no clock source" - aka stop the timer
	TCCR1B &= ~(3 << CS10);
}

void init_sonar(void (*ping_response_callback)(int distance)) {
	_ping_response_callback = ping_response_callback;
	// Setup timer 1 for Input Capture (ICP1/PD4)
	TCCR1B |= _BV(ICES1);
	_start_timer();
}

ISR(TIMER1_CAPT_vect) {
	static uint16_t rising_timestamp;
	if (TCCR1B & _BV(ICES1)) { 					// Rising edge
		// Set input capture for falling edge
		TCCR1B &= ~_BV(ICES1);
		rising_timestamp = ICR1;
	} else { 									// Falling Edge
		_stop_timer();
		// Set input capture for rising edge
		TCCR1B |= _BV(ICES1);
		// The falling edge triggered the ISR
		uint32_t delta = (uint32_t) ICR1 - (uint32_t) rising_timestamp;
		_ping_response_callback(delta * DELTA_MULTIPLIER);
		_start_timer();
	}
}

#endif /* SONAR_H_ */
