/*
 * main.c
 *
 *  Created on: May 17, 2013
 *      Author: andpol
 */

#include "PIR.h"
#include "UART.h"
#include "Sonar.h"
#include "Roomba.h"
#include <util/delay.h>

#define ROOMBA_SPEED 200
#define INITIAL_DELAY 2500
#define FOLLOW_DISTANCE 100
#define SONAR_EPSILON 10
#define SONAR_SAMPLE_COUNT 5
#define INTRUDER_TIMEOUT_SEC 5

// Globals
bool are_you_there = false;
int sonar_samples[SONAR_SAMPLE_COUNT];
uint8_t sonar_samples_index = 0;
uint8_t led_bits[] = { 0x0, 0xFF, 0xFF };
// The total running time of the system since boot, in seconds.
uint64_t runtime_sec = 0;

#define POWER_LED_GREEN 0
#define POWER_LED_YELLOW 128
#define POWER_LED_RED 255

void powerLedSet(uint8_t green_to_red) {
	led_bits[1] = green_to_red;
	_roomba_send_command(OC_LEDS, 3, led_bits);
}

void PIR_state_change(bool detected) {
	// Toggle the board LED
	PORTB ^= _BV(PB7);
	are_you_there = detected;
}

void sonar_distance_callback(int cm) {
	// Store the most recent distance reading
	sonar_samples[sonar_samples_index] = cm;
	sonar_samples_index = (sonar_samples_index + 1) % SONAR_SAMPLE_COUNT;
}

void turn90(bool right) {
	roomba_drive(200, right ? -1 : 1);

	int i;
	for (i = 0; i < 800; i++) {
		if (are_you_there) {
			roomba_drive(0, RADIUS_STRAIGHT);
			break;
		}

		_delay_ms(1);
	}
}

inline void _start_runtime_timer() {
	// Enable Ouput Compare A Match Interrupts
	TIMSK3 = _BV(OCIE3A);
	// Set the timer count to 0
	TCNT3 = 0;
	// Output compare register (ch A) value equivalent to 1 second (for 256 prescaler)
	OCR3A = 62500;
	// Start timer using a prescaler of 256
	TCCR3B |= (3 << CS32);
}

ISR(TIMER3_COMPA_vect) {
	runtime_sec++;
	UART_print(UART_CHANNEL_0, "Runtime: %d\n", runtime_sec);
}

int main() {
	DDRB = _BV(PB7);
	sei();

	init_UART(UART_CHANNEL_0, 57600, NULL );
	init_sonar(sonar_distance_callback);
	init_PIR(PIR_state_change);
	_start_runtime_timer();

	UART_print(UART_CHANNEL_0, "roomba init\n");
	init_roomba();

	uint8_t data[] = { 0x1, 0xFF, 0xFF };
	_roomba_send_command(OC_LEDS, 3, data);

	_delay_ms(INITIAL_DELAY);
	UART_print(UART_CHANNEL_0, "roomba init'ed\n");

	for (;;) {
		// Drive forwards
		roomba_drive(ROOMBA_SPEED, RADIUS_STRAIGHT);
		// Set green LED
		powerLedSet(POWER_LED_YELLOW);

		UART_print(UART_CHANNEL_0, "patrolling\n");

		// Patrol state
		for (;;) {
			// If hit wall (both kinds), turn
			ROOMBA_PACKET_1 packet = roomba_sense_1();
			if (packet.virtual_wall) {
				turn90(runtime_sec % 2);
				roomba_drive(ROOMBA_SPEED, RADIUS_STRAIGHT);
			} else if (packet.bumps_wheeldrops & 3) {
				if (packet.bumps_wheeldrops & 1) {
					turn90(false);
					roomba_drive(ROOMBA_SPEED, RADIUS_STRAIGHT);
				} else {
					turn90(true);
					roomba_drive(ROOMBA_SPEED, RADIUS_STRAIGHT);
				}
			}

			// If PIR triggered (intruder detected)
			if (are_you_there) {
				UART_print(UART_CHANNEL_0, "intruder detected\n");

				roomba_drive(0, RADIUS_STRAIGHT);
				powerLedSet(POWER_LED_RED);
				break;
			}
		}

		int intruder_detect_timestamp = runtime_sec;

		// Scan and follow state
		for (;;) {

			if (!are_you_there) {
				// After INTRUDER_TIMEOUT_SEC seconds, assume give up.
				if (runtime_sec - intruder_detect_timestamp >= INTRUDER_TIMEOUT_SEC) {
					UART_print(UART_CHANNEL_0, "intruder lost\n");
					break;
				}
			} else {
				// Reset the timestamp, PIR still active
				intruder_detect_timestamp = runtime_sec;
			}

			// Get an average sonar distance over the last N samples (critical section, no interrupts!)
			int sonar_distance_avg = 0;
			int i;
			cli();
			for (i = 0; i < SONAR_SAMPLE_COUNT; i++) {
				sonar_distance_avg += sonar_samples[i];
			}
			sonar_distance_avg /= SONAR_SAMPLE_COUNT;
			sei();

			UART_print(UART_CHANNEL_0, "distance: %d\n", sonar_distance_avg);
			// Too close
			if (sonar_distance_avg < FOLLOW_DISTANCE - SONAR_EPSILON) {
				roomba_drive(-200, RADIUS_STRAIGHT);
			}
			// Too far
			else if (sonar_distance_avg > FOLLOW_DISTANCE + SONAR_EPSILON) {
				roomba_drive(200, RADIUS_STRAIGHT);
			}
			// Stay still
			else {
				roomba_drive(0, RADIUS_STRAIGHT);
			}

			// Exit following state in case of a virtual wall detect
			ROOMBA_PACKET_1 packet1 = roomba_sense_1();
			if (packet1.virtual_wall) {
				roomba_drive(0, RADIUS_STRAIGHT);
				break;
			}
		}
	}
}
