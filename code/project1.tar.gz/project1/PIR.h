/*
 * PIR.h
 *
 *  Created on: May 17, 2013
 *      Author: andpol
 */

#ifndef PIR_H_
#define PIR_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdbool.h>

/*
 * PIR Sensor Wiring:
 * 	- PIR[out] -> PD2 (labeled pin 19)
 */

void (*_PIR_trigger_funct)(bool enabled);

void init_PIR(void (*PIR_trigger_funct)(bool enabled)) {
	uint8_t sreg = SREG;
	cli();

	_PIR_trigger_funct = PIR_trigger_funct;

	// Configure INT2 for rising & falling edge trigger
	EICRA |= _BV(ISC20);
	// Unmask INT2 (PD2)
	EIMSK |= _BV(INT2);

	SREG = sreg;
}

ISR(INT2_vect) {
	_PIR_trigger_funct(PIND & _BV(PD2));
}

#endif /* PIR_H_ */
