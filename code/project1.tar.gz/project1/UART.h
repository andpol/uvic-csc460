/*
 * UART.h
 *
 *  Created on: May 17, 2013
 *      Author: andpol
 */

#ifndef UART_H_
#define UART_H_

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>

#include "c_buffer.h"

// The Baud Rate Register value
#define MYBRR(baud_rate) (F_CPU / 16 / (baud_rate) - 1)

typedef enum {
	UART_CHANNEL_0, UART_CHANNEL_3
} UART_CHANNEL;

// The function that is called when data is received
void (*_recv_functs[2])(uint8_t);

#define TX_BUFFER_SIZE 64
// One buffer per UART channel
cirBuffer_t tx_buffer[2];

/**
 * Initialize the UART interface (enabling global interrupts) with default frame format:
 * - 8 data bits
 * - 1 stop bit
 * - no parity bit
 *
 * @param recv_func
 * 	the receive function that will be called when a character is received on the UART interface
 */
void init_UART(UART_CHANNEL ch, uint32_t baud_rate, void (*recv_func)(uint8_t)) {
	uint8_t sreg = SREG;
	cli();

	_recv_functs[ch] = recv_func;
	init_cirBuffer(&tx_buffer[ch], TX_BUFFER_SIZE);

	switch (ch) {
		case UART_CHANNEL_0:
			// Set baud rate
			UBRR0 = MYBRR(baud_rate);
			// Enable receiver and transmitter and their ISRs
			if (recv_func == NULL )
				UCSR0B = _BV(RXEN0) | _BV(TXEN0) | _BV(TXCIE0);
			else
				UCSR0B = _BV(RXEN0) | _BV(RXCIE0) | _BV(TXEN0) | _BV(TXCIE0);
			// Default frame format: 8 data, 1 stop bit , no parity
			break;
		case UART_CHANNEL_3:
			// Set baud rate
			UBRR3 = MYBRR(baud_rate);
			// Enable receiver and transmitter and their ISRs
			if (recv_func == NULL )
				UCSR3B = _BV(RXEN3) | _BV(TXEN3) | _BV(TXCIE3);
			else
				UCSR3B = _BV(RXEN3) | _BV(RXCIE3) | _BV(TXEN3) | _BV(TXCIE3);
			// Default frame format: 8 data, 1 stop bit , no parity
			break;
		default:
			break;
	}
	SREG = sreg;
}

uint8_t rxByteBlocking(UART_CHANNEL ch) {
	switch (ch) {
		case UART_CHANNEL_0:
			while (!(UCSR0A & _BV(RXC0)))
				;
			return UDR0 ;
		case UART_CHANNEL_3:
			while (!(UCSR3A & _BV(RXC3)))
				;
			return UDR3 ;
		default:
			// Illegal argument
			return 0;
	}
}

/**
 * Transmits the next character from the UART TX buffer, if one is available.
 */
void _txChar(UART_CHANNEL ch) {
	uint8_t sreg = SREG;
	cli();

	bool UART_busy;
	volatile uint8_t* UART_data_port;

	switch (ch) {
		case UART_CHANNEL_0:
			UART_busy = (UCSR0A & _BV(UDRE0));
			UART_data_port = &UDR0;
			break;
		case UART_CHANNEL_3:
			UART_busy = (UCSR3A & _BV(UDRE3));
			UART_data_port = &UDR3;
			break;
		default:
			// Illegal argument
			SREG = sreg;
			return;
	}

	// Nothing to write or the UART is busy
	if (tx_buffer[ch].len <= 0 || !UART_busy) {
		SREG = sreg;
		return;
	}

	// Put data into buffer (sends the data), and update the circular TX buffer
	*UART_data_port = tx_buffer[ch].data[tx_buffer[ch].start];
	tx_buffer[ch].start = (tx_buffer[ch].start + 1) % TX_BUFFER_SIZE;
	tx_buffer[ch].len--;
	SREG = sreg;
}

// UART RX Interrupt Service Routine
ISR(USART0_RX_vect) {
	if (_recv_functs[UART_CHANNEL_0] != NULL )
		(*_recv_functs[UART_CHANNEL_0])(UDR0 );
}

ISR(USART3_RX_vect) {
	if (_recv_functs[UART_CHANNEL_3] != NULL )
		(*_recv_functs[UART_CHANNEL_3])(UDR3 );
}

// UART TX Interrupt Service Routine
ISR(USART0_TX_vect) {
	_txChar(UART_CHANNEL_0);
}

// UART TX Interrupt Service Routine
ISR(USART3_TX_vect) {
	_txChar(UART_CHANNEL_3);
}

/**
 * non-blocking printf() syntax output to the UART interface.
 *
 * @param ch
 * @param fmt
 * @return
 */
size_t UART_print(UART_CHANNEL ch, const char* fmt, ...) {
	uint8_t sreg = SREG;
	cli();
	char buffer[TX_BUFFER_SIZE];
	va_list args;
	size_t size;
	va_start(args, fmt);
	size = vsnprintf(buffer, sizeof(buffer) - 1, fmt, args);
	va_end(args);

	// Error case: do not output to UART
	if (size < 0) {
		SREG = sreg;
		return size;
	}

	{
		uint8_t i = 0;
		// Append all the chars to the TX UART buffer
		while (buffer[i] != '\0') {
			tx_buffer[ch].data[(tx_buffer[ch].start + tx_buffer[ch].len + i) % TX_BUFFER_SIZE] = buffer[i];
			i++;
		}
		tx_buffer[ch].len += size;
	}
	// Transmit the first char now (if possible), remaining will be sent via the ISR
	_txChar(ch);

	SREG = sreg;
	return size;
}

void UART_send_raw_bytes(UART_CHANNEL ch, uint8_t num_bytes, uint8_t* data) {
	uint8_t sreg = SREG;
	cli();
	uint8_t i;
	for (i = 0; i < num_bytes; i++) {
		tx_buffer[ch].data[(tx_buffer[ch].start + tx_buffer[ch].len + i) % TX_BUFFER_SIZE] = data[i];
	}
	tx_buffer[ch].len += i;
	SREG = sreg;

	// Transmit the first char now (if possible), remaining will be sent via the ISR
	_txChar(ch);
}

#endif /* UART_H_ */
