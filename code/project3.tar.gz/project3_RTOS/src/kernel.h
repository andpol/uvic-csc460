/*
 * kernel.h
 *
 *  Created on: Jul 7, 2013
 *      Author: andpol
 */

#ifndef KERNEL_H_
#define KERNEL_H_

#include "error.h"
#include "proc_lists.h"
#include "BlockingUART.h"

#include <avr/interrupt.h>
#include <util/delay.h>

#include <stdbool.h>

//#define DEBUG 1

#define RR_TICK (QUANTUM / TICK)

// The number of elapsed Ticks since OS_Init()
uint32_t num_ticks = 0;

// The array of processes (extra space for the idle task)
process_descriptor_t procs[MAXPROCESS + 1];

// The kernel's stack pointer
volatile uint16_t kernel_sp;
process_descriptor_t * cur_process = NULL;

/*
 * The "naked" attribute prevents the compiler from adding instructions
 * to save and restore register values. It also prevents an
 * automatic return instruction.
 */
void enter_kernel(void) __attribute((noinline, naked));
void exit_kernel(void) __attribute((noinline, naked));

typedef enum {
	K_REQ_NONE, // Default case
	K_REQ_TIMER_TICK,
	K_REQ_TASK_TERMINATE,
	K_REQ_TASK_NEXT,
	K_REQ_TASK_WAIT,
	K_REQ_TASK_SIGNAL,
} kernel_request_t;

kernel_request_t kernel_request = K_REQ_TIMER_TICK;

/*
 * Context switching
 */
/**
 * It is important to keep the order of context saving and restoring exactly
 * in reverse. Also, when a new task is created, it is important to
 * initialize its "initial" context in the same order as a saved context.
 *
 * Save r31 and SREG on stack, disable interrupts, then save
 * the rest of the registers on the stack. In the locations this macro
 * is used, the interrupts need to be disabled, or they already are disabled.
 */
#define    SAVE_CTX_TOP()       asm volatile (\
    "push   r31             \n\t"\
    "in     r31,__SREG__    \n\t"\
    "cli                    \n\t"::) /* Disable interrupts, just in case, for the actual context switch */

#define STACK_SREG_SET_I_BIT()    asm volatile (\
    "ori    r31, 0x80        \n\t"::)

#define    SAVE_CTX_BOTTOM()       asm volatile (\
    "push   r31             \n\t"\
    "push   r30             \n\t"\
    "push   r29             \n\t"\
    "push   r28             \n\t"\
    "push   r27             \n\t"\
    "push   r26             \n\t"\
    "push   r25             \n\t"\
    "push   r24             \n\t"\
    "push   r23             \n\t"\
    "push   r22             \n\t"\
    "push   r21             \n\t"\
    "push   r20             \n\t"\
    "push   r19             \n\t"\
    "push   r18             \n\t"\
    "push   r17             \n\t"\
    "push   r16             \n\t"\
    "push   r15             \n\t"\
    "push   r14             \n\t"\
    "push   r13             \n\t"\
    "push   r12             \n\t"\
    "push   r11             \n\t"\
    "push   r10             \n\t"\
    "push   r9              \n\t"\
    "push   r8              \n\t"\
    "push   r7              \n\t"\
    "push   r6              \n\t"\
    "push   r5              \n\t"\
    "push   r4              \n\t"\
    "push   r3              \n\t"\
    "push   r2              \n\t"\
    "push   r1              \n\t"\
    "push   r0              \n\t"::)

/**
 * @brief Push all the registers and SREG onto the stack.
 */
#define    SAVE_CTX()    SAVE_CTX_TOP();SAVE_CTX_BOTTOM();

/**
 * @brief Pop all registers and the status register.
 */
#define    RESTORE_CTX()    asm volatile (\
    "pop    r0                \n\t"\
    "pop    r1                \n\t"\
    "pop    r2                \n\t"\
    "pop    r3                \n\t"\
    "pop    r4                \n\t"\
    "pop    r5                \n\t"\
    "pop    r6                \n\t"\
    "pop    r7                \n\t"\
    "pop    r8                \n\t"\
    "pop    r9                \n\t"\
    "pop    r10             \n\t"\
    "pop    r11             \n\t"\
    "pop    r12             \n\t"\
    "pop    r13             \n\t"\
    "pop    r14             \n\t"\
    "pop    r15             \n\t"\
    "pop    r16             \n\t"\
    "pop    r17             \n\t"\
    "pop    r18             \n\t"\
    "pop    r19             \n\t"\
    "pop    r20             \n\t"\
    "pop    r21             \n\t"\
    "pop    r22             \n\t"\
    "pop    r23             \n\t"\
    "pop    r24             \n\t"\
    "pop    r25             \n\t"\
    "pop    r26             \n\t"\
    "pop    r27             \n\t"\
    "pop    r28             \n\t"\
    "pop    r29             \n\t"\
    "pop    r30             \n\t"\
    "pop    r31             \n\t"\
	"out    __SREG__, r31    \n\t"\
    "pop    r31             \n\t"::)

/**
 * @fn enter_kernel
 *
 * @brief All system calls eventually enter here.
 *
 * Assumption: We are still executing on cur_task's stack.
 * The return address of the caller of enter_kernel() is on the
 * top of the stack.
 */
void enter_kernel(void) {
	// The PC was pushed on the stack with the call to this function.
	// Now push on the I/O registers and the SREG as well.
	SAVE_CTX()

	cur_process->sp = (uint8_t *) ((((uint16_t) *(&SP + 1) << 8) | (uint16_t) SP ));

	// Restore the kernel's context, SP first.
	// XXX: set the SP bytes manually, since setting the SP directly doesn't work!
	SP = (uint8_t) (kernel_sp);
	*(&SP + 1) = (uint8_t) ((volatile uint16_t) kernel_sp >> 8);

	// Now restore I/O and SREG registers.
	RESTORE_CTX();

	/*
	 * Assembly return instruction required since the C-level return expands to assembly code that
	 * restores context, but we do that manually.
	 */
	asm volatile ("ret\n"::);
	// returns to kernel context
}

/**
 * @fn exit_kernel
 *
 * @brief The actual context switching code begins here.
 *
 * This function is called by the kernel. Upon entry, we are using
 * the kernel stack, on top of which is the address of the instruction
 * after the call to exit_kernel().
 *
 * Assumption: Our kernel is executed with interrupts already disabled.
 */
void exit_kernel(void) {
	// The PC was pushed on the stack with the call to this function.
	// Now push on the I/O registers and the SREG as well.
	SAVE_CTX()

	//The last piece of the context is the SP. Save it to a variable.
	kernel_sp = ((uint16_t) *(&SP + 1) << 8) | ((uint16_t) SP );

	// XXX: set the SP bytes manually, since setting the SP directly doesn't work!
	SP = (uint8_t) cur_process->sp;
	*(&SP + 1) = (uint8_t) ((volatile uint16_t) cur_process->sp >> 8);

	// Restore I/O and SREG registers.
	RESTORE_CTX();
	/*
	 * Assembly return instruction required since the C-level return expands to assembly code that
	 * restores context, but we do that manually.
	 */
	asm volatile ("ret\n"::);
	// returns to process's context
}

// If bonus_tick is 'true', and a PERIODIC or RR task is scheduled, it is given an additional tick
// to it's ticks_remaining attribute. This is used to handle a task only receiving a fraction of a tick.
void schedule_process(bool bonus_tick) {

	// Test if there's a periodic task that overlap with itself
	if (periodic_procs.len >= 1) {
		process_descriptor_t * p = proc_list_peek(&periodic_procs);
		if (num_ticks >= p->next_start + p->period) {
			errno = ERRNO_PERIODIC_TASK_OVERLAP;
			OS_Abort();
		}
	}

	// Schedule a new process based on priority
	if (system_procs.len > 0) {
#ifdef DEBUG
		UART_print("s");
#endif
		cur_process = proc_list_peek(&system_procs);
	} else if (periodic_procs.len > 0 && num_ticks >= proc_list_peek(&periodic_procs)->next_start) {
#ifdef DEBUG
		UART_print("p");
		UART_print("%d", num_ticks);
#endif
		process_descriptor_t * periodic_task = proc_list_peek(&periodic_procs);
		// Check for overlap with another periodic task
		if (periodic_task->next != NULL && num_ticks >= periodic_task->next->next_start) {
			errno = ERRNO_PERIODIC_TASK_OVERLAP;
			OS_Abort();
		}
		cur_process = periodic_task;
		if (bonus_tick) {
			cur_process->ticks_remaining += 1;
		}
	} else if (rr_procs.len > 0) {
#ifdef DEBUG
		UART_print("r");
#endif
		cur_process = proc_list_peek(&rr_procs);
		if (bonus_tick) {
			cur_process->ticks_remaining += 1;
		}
	} else {
#ifdef DEBUG
		UART_print("i");
#endif
		cur_process = idle_proc;
	}
#ifdef DEBUG
	UART_print(" ");
#endif
	cur_process->state = RUNNING;
}

void kernel_handle_request() {
	switch (kernel_request) {
		case K_REQ_NONE:
			return;
		case K_REQ_TIMER_TICK:
			switch (cur_process->type) {
				case SYSTEM: // drop down
				case IDLE:
					break;
				case PERIODIC: // drop down
					cur_process->ticks_remaining--;
					if (cur_process->ticks_remaining <= 0) {
						errno = ERRNO_PERIODIC_TASK_EXCEEDS_WCET;
						OS_Abort();
					}
					break;
				case RR:
					cur_process->ticks_remaining--;
					if (cur_process->ticks_remaining == 0) {
						// Reset ticks and move to back
						cur_process->ticks_remaining = RR_TICK;
						proc_list_append(&rr_procs, proc_list_pop(&rr_procs));
					}
					break;
			}
			cur_process->state = READY;
			schedule_process(false);
			break;
		case K_REQ_TASK_NEXT:
#ifdef DEBUG
			UART_print("TN ");
#endif
			switch (cur_process->type) {
				case SYSTEM:
#ifdef DEBUG
					UART_print("S ");
#endif
					proc_list_append(&system_procs, proc_list_pop(&system_procs));
					break;
				case PERIODIC:
#ifdef DEBUG
					UART_print("P ");
#endif
					proc_list_pop(&periodic_procs);
					cur_process->next_start = cur_process->next_start + cur_process->period;
					cur_process->ticks_remaining = cur_process->wcet;
					proc_list_insert_into_offset_order(&periodic_procs, cur_process);
					break;
				case RR:
#ifdef DEBUG
					UART_print("R ");
#endif
					// Reset ticks and move to back
					cur_process->ticks_remaining = RR_TICK;
					proc_list_append(&rr_procs, proc_list_pop(&rr_procs));
					break;
			}
			cur_process->state = READY;
			schedule_process(false);
			break;
		case K_REQ_TASK_TERMINATE:
			switch (cur_process->type) {
				case SYSTEM:
					proc_list_pop(&system_procs);
					break;
				case PERIODIC:
					proc_list_pop(&periodic_procs);
					break;
				case RR:
					proc_list_pop(&rr_procs);
					break;
			}
#ifdef DEBUG
			UART_print("k");
#endif
			cur_process->state = DEAD;
			schedule_process(false);
			break;
		case K_REQ_TASK_WAIT:
			switch (cur_process->type) {
				case PERIODIC:
					errno = ERRNO_PERIODIC_CALLED_WAIT;
					OS_Abort();
					break;
				case SYSTEM:
					proc_list_append(&waiting_procs, proc_list_pop(&system_procs));
					break;
				case RR:
					proc_list_append(&waiting_procs, proc_list_pop(&rr_procs));
					break;
			}
			cur_process->state = BLOCKED;
			schedule_process(false);
			break;
		case K_REQ_TASK_SIGNAL:
			// search for the wait queue for the ready process
			if (waiting_procs.len == 0) {
				errno = ERRNO_UNKNOWN_ERR;
				OS_Abort();
			}
			process_descriptor_t * p = proc_list_pop_first(&waiting_procs, READY);
			switch (p->type) {
				case SYSTEM:
					proc_list_append(&system_procs, p);
					break;
				case RR:
					proc_list_append(&rr_procs, p);
					break;
			}
			// We may need to reschedule the current process if a lower priority signaled a higher priority
			cur_process->state = READY;
			schedule_process(true);
			break;
		default:
			errno = ERRNO_INVALID_KERNEL_REQ;
			OS_Abort();
	}

	kernel_request = K_REQ_NONE;
}

static void kernel_main_loop() {
	for (;;) {
		// Handles any requests made by the process (if any)
		kernel_handle_request();

		// Exits the kernel, switching contexts to the next process
		exit_kernel();
		// Process returns to here.
	}
}

static process_descriptor_t * kernel_create_proc(uint8_t type, void (*funct)(void)) {

	if (type != SYSTEM && type != PERIODIC && type != RR && type != IDLE) {
		errno = ERRNO_INVALID_PROC_TYPE;
		OS_Abort();
	}

	process_descriptor_t * p = NULL;
	int i;
// Find the first free proc descriptor
	for (i = 0; i < MAXPROCESS + 1; i++) {
		if (procs[i].state == DEAD) {
			p = &procs[i];
			break;
		}
	}
	if (p == NULL) {
		errno = ERRNO_EXCEEDS_MAX_PROCS;
		OS_Abort();
	}

	p->type = type;
	p->pid = i;
	p->ticks_remaining = 0;

	uint8_t * stack_bottom = &(p->stack[MAXSTACK - 1]);

	/* The stack grows down in memory, so the stack pointer is going to end up
	 * pointing to the location 31 + 1 + 1 + 2 + 2 = 37 bytes above the bottom, to make
	 * room for (from bottom to top):
	 *   - 2 bytes: the address of Task_Terminate() to destroy the task if it ever returns,
	 *   - 2 bytes: the address of the start of the task to "return" to the first time it runs
	 *   - 1 byte: register 31,
	 *   - 1 byte: the stored SREG, and
	 *   - 31 bytes: registers 30 to 0.
	 */
	uint8_t * stack_top = stack_bottom - (31 + 1 + 1 + 2 + 2);

	/* stack_top[0] is the byte above the stack.
	 * stack_top[1] is r0. */
	stack_top[2] = (uint8_t) 0; /* r1 is the AVR "zero" register. */
	/* ... */
	/* stack_top[31] is r30. */
	stack_top[32] = (uint8_t) _BV(SREG_I); /* set SREG_I bit in stored SREG. */
	/* stack_top[33] is r31. */

	stack_top[34] = (uint8_t) ((uint16_t) (funct) >> 8);
	stack_top[35] = (uint8_t) (uint16_t) (funct);

	stack_top[36] = (uint8_t) ((uint16_t) Task_Terminate >> 8);
	stack_top[37] = (uint8_t) (uint16_t) Task_Terminate;

// Make stack pointer point to cell above the stack (the top), since AVR SP always points to an empty position
	p->sp = stack_top;
	p->state = READY;

	return p;
}

#endif /* KERNEL_H_ */
