#include "trace.h"

#include <util/delay.h>
#include <avr/interrupt.h>

#include <string.h>

void task() {
	for (;;) {
		PORTD ^= _BV(PD5);
		Task_Next();
	}
}

void main() {
	UART_Init0(57600);
	DDRD = _BV(PD5);

	Task_Create_Period(task, 0, 20, 1, 0);
}
