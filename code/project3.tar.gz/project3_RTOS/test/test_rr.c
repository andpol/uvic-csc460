/*
 * Tests that the RTOS correctly schedules RR tasks.
 */

#include "trace.h"

#include <util/delay.h>
#include <avr/interrupt.h>

#include <string.h>

EVENT * print_event;

int count = 0;

void task(void) {
	int arg = 0;
	arg = Task_GetArg();

	for (;;) {
		add_trace(arg, ENTER);

		if (arg == 7) {
			Event_Signal(print_event);
		}
		add_trace(arg, EXIT);
		Task_Next();
	}
}

void err_handler() {
	UART_print("fail");
}

void test_results() {
	Event_Wait(print_event);
	char * trace = get_trace();
	char * correct_trace = "(0,0),(1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),";
	UART_print("Trace: %s\n", trace);
	if (strcmp(correct_trace, trace) == 0) {
		UART_print("pass");
	} else {
		UART_print("fail");
	}
}

void main() {
	UART_Init0(57600);
	set_error_handler(err_handler);
	print_event = Event_Init();
	Task_Create_System(test_results, 0);

	UART_print("\ntest begin\n");

	Task_Create_RR(task, 0);
	Task_Create_RR(task, 1);
	Task_Create_RR(task, 2);
	Task_Create_RR(task, 3);
	Task_Create_RR(task, 4);
	Task_Create_RR(task, 5);
	Task_Create_RR(task, 6);
	Task_Create_RR(task, 7);
}
