/*
 * Tests that the RTOS correctly schedules periodic tasks.
 * Tasks have the same period and wcet, but different offsets.
 */

#include "trace.h"

#include <util/delay.h>
#include <avr/interrupt.h>

#include <string.h>

EVENT * print_event;

void task() {
	int arg = Task_GetArg();
	add_trace(arg, ENTER);
	add_trace(arg, EXIT);
	if (arg == 7) {
		Event_Signal(print_event);
	}
	Task_Next();
}

void err_handler() {
	UART_print("fail");
}

void test_results() {
	Event_Wait(print_event);
	char * trace = get_trace();
	char * correct_trace = "(0,0),(1,1),(2,2),(3,3),(4,4),(5,5),(6,6),(7,7),";
	UART_print("Trace: %s\n", trace);
	if (strcmp(correct_trace, trace) == 0) {
		UART_print("pass");
	} else {
		UART_print("fail");
	}
}

void main() {
	UART_Init0(57600);
	set_error_handler(err_handler);
	print_event = Event_Init();
	Task_Create_System(test_results, 0);

	UART_print("\ntest begin\n");

	// Full schedule; 8 tasks, each executing for 1 tick every 8 ticks
	Task_Create_Period(task, 0, 8, 1, 0);
	Task_Create_Period(task, 1, 8, 1, 1);
	Task_Create_Period(task, 2, 8, 1, 2);
	Task_Create_Period(task, 3, 8, 1, 3);
	Task_Create_Period(task, 4, 8, 1, 4);
	Task_Create_Period(task, 5, 8, 1, 5);
	Task_Create_Period(task, 6, 8, 1, 6);
	Task_Create_Period(task, 7, 8, 1, 7);
}
