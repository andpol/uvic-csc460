/*
 * Tests that a periodic task waiting on an event causes an error.
 */

#include "trace.h"
#include <util/delay.h>

#include <avr/io.h>

EVENT * print_event;
EVENT * test_event;

void task() {
	for (;;) {
		Event_Wait(test_event);
	}
}

void err_handler() {
	if (errno == ERRNO_PERIODIC_CALLED_WAIT) {
		UART_print("pass");
	} else {
		UART_print("fail");
	}
}

void print_task() {
	Event_Wait(print_event);
	print_trace();
	UART_print("fail");
}

void main() {
	UART_Init0(57600);
	set_error_handler(err_handler);
	print_event = Event_Init();

	UART_print("\ntest begin\n");

	test_event = Event_Init();
	Task_Create_Period(task, 0, 10, 5, 0);
}
