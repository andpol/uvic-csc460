/*
 * Tests a waiting SYSTEM level process signaled by a PERIODIC task.
 *
 * SYSTEM level task waking up should preempt the signaling PERIODIC task.
 */

#include "trace.h"

#include <util/delay.h>
#include <avr/io.h>

#include <string.h>

EVENT * print_event;
EVENT * test_event;

void test_signal() {
	int arg = Task_GetArg();
	for (;;) {
		add_trace(arg, ENTER);
		Event_Signal(test_event);
		add_trace(arg, EXIT);
		Event_Signal(print_event);
		Task_Next();
	}
}

void test_waiting() {
	int arg = Task_GetArg();
	for (;;) {
		add_trace(arg, ENTER);
		Event_Wait(test_event);
		add_trace(arg, EXIT);
		Task_Next();
	}
}

void err_handler() {
	UART_print("fail");
}

void test_results() {
	Event_Wait(print_event);
	char * trace = get_trace();
	char * correct_trace = "(0,(1,0),(0,1),";
	UART_print("Trace: %s\n", trace);
	if (strcmp(correct_trace, trace) == 0) {
		UART_print("pass");
	} else {
		UART_print("fail");
	}
}

void main() {
	UART_Init0(57600);
	set_error_handler(err_handler);
	print_event = Event_Init();
	test_event = Event_Init();
	Task_Create_System(test_results, 0);

	UART_print("\ntest begin\n");

	Task_Create_System(test_waiting, 0);
	Task_Create_Period(test_signal, 1, 50, 10, 0);
}
