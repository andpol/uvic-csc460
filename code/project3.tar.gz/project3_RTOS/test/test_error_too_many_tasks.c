/*
 * Tests that the RTOS generates an error when too many tasks are created.
 */

#include "trace.h"
#include <util/delay.h>

#include <avr/io.h>

void task() {
	for (;;) {
		Task_Next();
	}
}

void err_handler() {
	if (errno == ERRNO_EXCEEDS_MAX_PROCS) {
		UART_print("pass");
	} else {
		UART_print("fail");
	}
}

void main() {
	UART_Init0(57600);
	set_error_handler(err_handler);

	UART_print("\ntest begin\n");

	int i;
	for (i = 0; i <= MAXPROCESS; i++) {
		Task_Create_System(task, i);
	}

	// Should not get to this line
	UART_print("fail");
}
