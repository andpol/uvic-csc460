/*
 * Test that a system task running before a period task for too long triggers
 * an OS_Abort().
 */
#include "trace.h"

#include <util/delay.h>
#include <avr/interrupt.h>

#include <string.h>

EVENT * print_event;

void sys_task(void) {
	int arg = 0;
	arg = Task_GetArg();
	add_trace(arg, ENTER);
	_delay_us(TICK * 6000);
	add_trace(arg, EXIT);
}

void periodic_task(void) {
	int arg = 0;
	arg = Task_GetArg();

	add_trace(arg, ENTER);
	_delay_us(TICK * 4000);
	add_trace(arg, EXIT);
	Event_Signal(print_event);
}

void err_handler() {
	if (errno == ERRNO_PERIODIC_TASK_OVERLAP) {
		UART_print("pass");
	} else {
		UART_print("fail");
	}
}

void test_results() {
	for (;;) {
		// NOP
	}
}

void main() {
	UART_Init0(57600);
	set_error_handler(err_handler);
	Task_Create_System(test_results, 0);
	print_event = Event_Init();

	UART_print("\ntest begin\n");

	Task_Create_System(sys_task, 0);
	Task_Create_Period(periodic_task, 1, 10, 5, 0);
}
