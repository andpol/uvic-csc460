/*
 * Test that a system task running in a periodic tasks place for a short duration does
 * not cause an error.
 */
#include "trace.h"

#include <util/delay.h>
#include <avr/interrupt.h>

#include <string.h>

EVENT * print_event;

void sys_task(void) {
	int arg = 0;
	arg = Task_GetArg();
	add_trace(arg, ENTER);
	_delay_us(TICK * 4500);
	add_trace(arg, EXIT);
}

void periodic_task(void) {
	int arg = 0;
	arg = Task_GetArg();

	add_trace(arg, ENTER);
	_delay_us(TICK * 4000);
	add_trace(arg, EXIT);
	Event_Signal(print_event);
}

void err_handler() {
	UART_print("fail");
}

void test_results() {
	Event_Wait(print_event);
	char * trace = get_trace();
	char * correct_trace = "(0,0),(1,1),";
	UART_print("Trace: %s\n", trace);
	if (strcmp(correct_trace, trace) == 0) {
		UART_print("pass");
	} else {
		UART_print("fail");
	}
}

void main() {
	UART_Init0(57600);
	set_error_handler(err_handler);
	Task_Create_System(test_results, 0);
	print_event = Event_Init();

	UART_print("\ntest begin\n");

	Task_Create_System(sys_task, 0);
	Task_Create_Period(periodic_task, 1, 10, 5, 0);
}
