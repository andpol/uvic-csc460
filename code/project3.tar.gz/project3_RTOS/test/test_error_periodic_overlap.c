/*
 * Tests that overlapping periodic tasks cause an error.
 */

#include "trace.h"
#include <util/delay.h>

#include <avr/io.h>

EVENT * print_event;

void task() {
	for (;;) {
		_delay_ms(4 * TICK);
		Task_Next();
	}
}

void err_handler() {
	if (errno == ERRNO_PERIODIC_TASK_OVERLAP) {
		UART_print("pass");
	} else {
		UART_print("fail");
	}
}

void print_task() {
	Event_Wait(print_event);
	UART_print("fail");
}

void main() {
	UART_Init0(57600);
	set_error_handler(err_handler);
	print_event = Event_Init();

	UART_print("\ntest begin\n");

	Task_Create_System(print_task, 0);

	// Runs on ticks 0-5
	Task_Create_Period(task, 0, 10, 5, 0);
	// Runs on ticks 1-6
	Task_Create_Period(task, 0, 10, 5, 1);
}
