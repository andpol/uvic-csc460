/*
 * Tests that RR tasks execute for 2 ticks, even when the longest they can run in
 * one go is 1 tick.
 */

#include "trace.h"

#include <util/delay.h>
#include <avr/interrupt.h>

#include <string.h>

EVENT * print_event;

int count = 0;

void periodic_task() {
	int arg = Task_GetArg();

	for (;;) {
		add_trace(arg, ENTER);
		count++;
		if (count > 4) {
			Event_Signal(print_event);
		}

		add_trace(arg, EXIT);
		Task_Next();
	}
}

void rr_task() {
	int arg = Task_GetArg();

	for (;;) {
		add_trace(arg, ENTER);
		_delay_ms(TICK);
	}
}

void err_handler() {
	UART_print("fail");
}

void test_results() {
	Event_Wait(print_event);
	char * trace = get_trace();
	char * correct_trace = "(0,0),(1,(1,(0,0),(2,(2,(0,0),(3,(3,(0,0),(4,(4,(0,";
	UART_print("Trace: %s\n", trace);
	if (strcmp(correct_trace, trace) == 0) {
		UART_print("pass");
	} else {
		UART_print("fail");
	}
}

void main() {
	UART_Init0(57600);
	set_error_handler(err_handler);
	print_event = Event_Init();
	Task_Create_System(test_results, 0);

	UART_print("\ntest begin\n");

	// Period: 2, wcet: 1, offset: 0
	Task_Create_Period(periodic_task, 0, 2, 1, 0);

	Task_Create_RR(rr_task, 1);
	Task_Create_RR(rr_task, 2);
	Task_Create_RR(rr_task, 3);
	Task_Create_RR(rr_task, 4);
	Task_Create_RR(rr_task, 5);
}
